import {evaluatePlanAuthority} from '../../brain/src/authorityGuard';
import {validateToolParameters,validateParameters} from '../../../packages/tool-gateway/src/validation';
import { withTransaction } from "../../../packages/db/src/client";
import { consumeApproval } from "../../../packages/db/src/approvals";
import { sha256Hex } from "../../../packages/shared/src/stableJson";
import type { CapabilityExecutor,ClaimedWork } from "../../kernel/src/workerRuntime";
import {
  beginSideEffectAtomic,
  bindSideEffectToWorkAtomic,
  markSideEffectSentAtomic
} from "../../kernel/src/sideEffects";
import type { CapabilityCatalog } from "../../agents/src/capabilityCatalog";
import type { ToolRegistry } from "../../../packages/tool-gateway/src/registry";

async function legalEntityForWork(queueId:string):Promise<string|null>{
  return withTransaction(async(client)=>{
    const r=await client.query(
      `SELECT g.company_scope
         FROM work_queue w
         LEFT JOIN goals g ON g.id=w.goal_id
        WHERE w.id=$1`,
      [queueId]
    );
    if(r.rowCount!==1) throw new Error("Work item not found");
    return r.rows[0].company_scope ?? null;
  });
}

export function createToolExecutors(input:{
  catalog:CapabilityCatalog;
  tools:ToolRegistry;
}):Record<string,CapabilityExecutor>{
  const executors:Record<string,CapabilityExecutor>={};

  for(const capabilityId of Object.keys(input.catalog.authorityPolicies())){
    const capability=input.catalog.get(capabilityId);
    const tool=input.tools.definition(capabilityId);

    if(tool.authorityClass!==capability.authorityClass){
      throw new Error(
        `Authority mismatch for ${capabilityId}: catalog=${capability.authorityClass} tool=${tool.authorityClass}`
      );
    }

    executors[capabilityId]=async(work:ClaimedWork)=>{
      const params=work.params ?? {};
      validateParameters(capability.parameters,params);
      validateToolParameters(capabilityId,params,tool.inputSchema);
      await withTransaction(async client=>{
        const row=(await client.query(`SELECT w.id,w.goal_id,w.plan_id,w.capability_id,g.authority_ceiling,g.company_scope FROM work_queue w JOIN goals g ON g.id=w.goal_id
          WHERE w.id=$1 AND w.fencing_token=$2 AND w.status IN ('LEASED','EXECUTING')
          AND w.lease_expiry>now() AND g.state='EXECUTING' AND g.current_plan_id=w.plan_id`,[work.queueId,work.fencingToken])).rows[0];
        if(!row||row.goal_id!==work.goalId||row.plan_id!==work.planId||row.capability_id!==work.capabilityId)throw new Error('EXECUTION_LEASE_OR_GOAL_INVALID');
        const rank={GREEN:0,YELLOW:1,RED:2};
        if(rank[capability.authorityClass]>rank[row.authority_ceiling as keyof typeof rank])throw new Error('EXECUTION_AUTHORITY_DENIED');
        if(!tool.sideEffect){
          const entity=row.company_scope;
          const authority=await evaluatePlanAuthority(client,{goalId:work.goalId!,legalEntityId:entity,
            steps:[{capabilityId,params}],capabilityPolicies:input.catalog.authorityPolicies()});
          if(!authority.authorized)throw new Error('EXECUTION_AUTHORITY_DENIED');
        }
      });
      const requestHash=sha256Hex(params);
      const operationKey=`tool:${work.goalId??work.queueId}:${capabilityId}:${requestHash}`;

      if(!tool.sideEffect){
        const result=await input.tools.adapter(capabilityId).execute({
          capabilityId,
          params,
          idempotencyKey:operationKey
        });
        return {
          result:result.result,
          evidence:{
            ...result.evidence,
            tool_capability:capabilityId,
            side_effect:false
          }
        };
      }

      const legalEntityId=await legalEntityForWork(work.queueId);
      // Reservation, approval consumption and live-work binding become visible
      // together. A reconciler must never observe an unbound pending write.
      const sideEffect=await withTransaction(async client=>{
        const current=await client.query(`SELECT w.id FROM work_queue w JOIN goals g ON g.id=w.goal_id
          WHERE w.id=$1 AND w.fencing_token=$2 AND w.status IN ('LEASED','EXECUTING')
          AND w.lease_expiry>now() AND g.state='EXECUTING' AND g.current_plan_id=w.plan_id
          FOR UPDATE OF w`,[work.queueId,work.fencingToken]);
        if(current.rowCount!==1)throw new Error('EXECUTION_LEASE_OR_GOAL_INVALID');
        const reserved=await beginSideEffectAtomic({
          operationKey,capabilityId,requestHash,goalId:work.goalId??null,
          legalEntityId,idempotencyKey:operationKey
        },client);
        if(reserved.created){
          if(capability.authorityClass!=='GREEN')await consumeApproval(client,{
            goalId:work.goalId,capabilityId,params,legalEntityId,authorityClass:capability.authorityClass
          });
          await bindSideEffectToWorkAtomic(work.queueId,operationKey,client);
        }
        return reserved;
      });

      if(!sideEffect.created){
        if(sideEffect.operation.request_hash!==requestHash){
          throw new Error("Operation key collision with different request hash");
        }
        if(sideEffect.operation.state==="CONFIRMED"){
          return {
            result:{
              deduplicated:true,
              provider_reference:sideEffect.operation.provider_reference ?? null
            },
            evidence:{
              ...(sideEffect.operation.reconciliation_evidence??{}),
              operation_key:operationKey,
              side_effect:true,
              deduplicated:true,
              reconciliation_state:sideEffect.operation.reconciliation_state
            }
          };
        }
        throw new Error(
          `Side effect ${operationKey} is ${sideEffect.operation.state}; reconciliation required before retry`
        );
      }

      const result=await input.tools.adapter(capabilityId).execute({
        capabilityId,
        params,
        idempotencyKey:operationKey
      });

      if(!result.providerReference){
        throw new Error("Side-effect tool must return providerReference");
      }

      await markSideEffectSentAtomic(operationKey,result.providerReference);

      return {
        result:result.result,
        evidence:{
          ...result.evidence,
          provider_reference:result.providerReference,
          operation_key:operationKey,
          side_effect:true,
          idempotency_key:operationKey
        }
      };
    };
  }

  return executors;
}
