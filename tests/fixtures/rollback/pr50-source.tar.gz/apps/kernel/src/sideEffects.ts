import type {PoolClient} from 'pg';
import { withTransaction } from "../../../packages/db/src/client";

export type SideEffectState = "PENDING" | "SENT" | "CONFIRMED" | "FAILED";

export async function beginSideEffectAtomic(input: {
  operationKey: string;
  capabilityId: string;
  requestHash: string;
  goalId?: string | null;
  legalEntityId?: string | null;
  idempotencyKey?: string | null;
}, transactionClient?:PoolClient) {
  const reserve=async (client:PoolClient) => {
    const inserted = await client.query(
      `INSERT INTO side_effect_operations
        (operation_key, capability_id, goal_id, legal_entity_id, request_hash, idempotency_key,reconciliation_state)
       VALUES($1,$2,$3,$4,$5,$6,'NEEDS_RECONCILIATION')
       ON CONFLICT(operation_key) DO NOTHING
       RETURNING *`,
      [
        input.operationKey,
        input.capabilityId,
        input.goalId ?? null,
        input.legalEntityId ?? null,
        input.requestHash,
        input.idempotencyKey ?? null
      ]
    );

    if (inserted.rowCount === 1) {
      return { created: true, operation: inserted.rows[0] };
    }

    const existing = await client.query(
      "SELECT * FROM side_effect_operations WHERE operation_key=$1 FOR UPDATE",
      [input.operationKey]
    );
    return { created: false, operation: existing.rows[0] };
  };
  return transactionClient?reserve(transactionClient):withTransaction(reserve);
}

export async function markSideEffectSentAtomic(
  operationKey: string,
  providerReference: string
): Promise<void> {
  await withTransaction(async (client) => {
    const res = await client.query(
      `UPDATE side_effect_operations
          SET state='SENT',
              provider_reference=$2,
              reconciliation_state='NEEDS_RECONCILIATION',
              attempt=attempt+1,
              updated_at=now()
        WHERE operation_key=$1
          AND state='PENDING'
        RETURNING id`,
      [operationKey, providerReference]
    );
    if (res.rowCount !== 1) {
      throw new Error("Side effect is not in PENDING state");
    }
  });
}

export async function confirmSideEffectAtomic(operationKey: string): Promise<void> {
  await withTransaction(async (client) => {
    const res = await client.query(
      `UPDATE side_effect_operations
          SET state='CONFIRMED',
              reconciliation_state='RECONCILED',
              last_reconciled_at=now(),
              updated_at=now()
        WHERE operation_key=$1
          AND state IN ('SENT','CONFIRMED')
        RETURNING id`,
      [operationKey]
    );
    if (res.rowCount !== 1) {
      throw new Error("Side effect cannot be confirmed from current state");
    }
  });
}

export async function bindSideEffectToWorkAtomic(
  queueId: string,
  operationKey: string,
  transactionClient?:PoolClient
): Promise<void> {
  const bind=async (client:PoolClient) => {
    const op = await client.query(
      "SELECT operation_key FROM side_effect_operations WHERE operation_key=$1 FOR UPDATE",
      [operationKey]
    );
    if (op.rowCount !== 1) throw new Error("Side effect operation not found");

    const work = await client.query(
      `UPDATE work_queue
          SET operation_key_ref=$2
        WHERE id=$1
          AND (operation_key_ref IS NULL OR operation_key_ref=$2)
        RETURNING id`,
      [queueId, operationKey]
    );
    if (work.rowCount !== 1) {
      throw new Error("Work item already bound to a different side effect");
    }
  };
  if(transactionClient)await bind(transactionClient);else await withTransaction(bind);
}
