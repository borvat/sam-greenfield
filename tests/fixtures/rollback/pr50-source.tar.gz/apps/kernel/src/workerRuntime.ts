import {prepareWorkParameters} from './dependencies';
import { withTransaction } from "../../../packages/db/src/client";
import { acquireLease } from "../../../packages/db/src/fencing";
import { recordExecutionAndRequestVerificationAtomic } from "./execution";
import {leaseAttemptLimit,stopExhaustedLease} from "./leaseBudget";

export interface ClaimedWork {
  queueId: string;
  fencingToken: number;
  capabilityId: string;
  params: Record<string, unknown>;
  goalId: string | null;
  planId: string | null;
}

export type CapabilityExecutor = (
  work: ClaimedWork
) => Promise<{ result: Record<string, unknown>; evidence: Record<string, unknown> }>;

export async function claimNextWorkAtomic(
  owner: string,
  ttlSeconds: number
): Promise<ClaimedWork | null> {
  const limit=leaseAttemptLimit();
  return withTransaction(async (client) => {
    const candidate = await client.query(
      `SELECT id,goal_id,attempt,fencing_token
         FROM work_queue
        WHERE status IN ('QUEUED','HANDBACK')
          AND (due_at IS NULL OR due_at <= now())
          AND (plan_id IS NULL OR work_dependencies_ready(id))
        ORDER BY priority DESC,due_at ASC NULLS FIRST,queued_at ASC,id ASC
        FOR UPDATE SKIP LOCKED
        LIMIT 1`
    );
    if (candidate.rowCount === 0) return null;
    if(limit!==null&&Number(candidate.rows[0].attempt)>=limit){
      await stopExhaustedLease(client,candidate.rows[0]);return null;
    }

    const queueId = candidate.rows[0].id as string;
    const fencingToken = await acquireLease(client, queueId, owner, ttlSeconds);
    const row = await client.query(
      "SELECT id,goal_id,plan_id,capability_id,params FROM work_queue WHERE id=$1",
      [queueId]
    );

    const params=await prepareWorkParameters(client,queueId,row.rows[0].params??{});
    if(!params)return null;
    return {
      queueId,
      fencingToken,
      capabilityId: row.rows[0].capability_id,
      params,
      goalId: row.rows[0].goal_id ?? null,
      planId: row.rows[0].plan_id ?? null
    };
  });
}

export async function runOneClaimedWork(
  owner: string,
  ttlSeconds: number,
  executors: Record<string, CapabilityExecutor>
): Promise<{ processed: boolean; executionId?: string; queueId?: string }> {
  const work = await claimNextWorkAtomic(owner, ttlSeconds);
  if (!work) return { processed: false };

  const executor = executors[work.capabilityId];
  if (!executor) {
    throw new Error(`No executor registered for capability ${work.capabilityId}`);
  }

  const outcome = await executor(work);
  const execution = await recordExecutionAndRequestVerificationAtomic({
    queueId: work.queueId,
    fencingToken: work.fencingToken,
    actor: owner,
    result: outcome.result,
    evidence: outcome.evidence
  });

  return {
    processed: true,
    executionId: execution.executionId,
    queueId: work.queueId
  };
}
