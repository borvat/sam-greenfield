# Independent SAM verification

Status: **FAIL**
Source: `9d131f1aba410659ef304cbdbcb49382c7daa1f6` (clean: true)
Started: 2026-10-22T14:51:37.725Z; completed: 2026-10-22T14:55:59.582Z

INDEPENDENT_LOCAL_SYNTHETIC_ACCEPTANCE_NOT_HOSTED_OR_PRODUCTION

| Check | Result | Log |
| --- | --- | --- |
| preflight | PASS | [log](logs/01-preflight.log) |
| snapshot | PASS | [log](logs/02-snapshot.log) |
| images | PASS | [log](logs/03-images.log) |
| isolated-postgres | PASS | [log](logs/04-isolated-postgres.log) |
| node-dependencies | PASS | [log](logs/05-node-dependencies.log) |
| python-dependencies | PASS | [log](logs/06-python-dependencies.log) |
| runtime-versions | PASS | [log](logs/07-runtime-versions.log) |
| workflow-tool | PASS | [log](logs/08-workflow-tool.log) |
| workflow-validation | PASS | [log](logs/09-workflow-validation.log) |
| configuration-validation | PASS | [log](logs/10-configuration-validation.log) |
| typecheck | PASS | [log](logs/11-typecheck.log) |
| regression | PASS | [log](logs/12-regression.log) |
| core-reliability | PASS | [log](logs/13-core-reliability.log) |
| provider-auth | PASS | [log](logs/14-provider-auth.log) |
| postgres-tls | PASS | [log](logs/15-postgres-tls.log) |
| contracts | FAIL | [log](logs/16-contracts.log) |
| synthetic-pilot | NOT_RUN | not executed |
| managed-schema | NOT_RUN | not executed |
| local-bundle | NOT_RUN | not executed |
| closed-setup | NOT_RUN | not executed |
| database-contract | NOT_RUN | not executed |
| prelaunch-gate | NOT_RUN | not executed |
| render-migration-compatibility | NOT_RUN | not executed |
| render-google-oauth-contracts | NOT_RUN | not executed |
| integration-migrations | NOT_RUN | not executed |
| integration-oauth-mcp | NOT_RUN | not executed |
| integration-orchestration | NOT_RUN | not executed |
| specialist-reasoning | NOT_RUN | not executed |
| specialist-gateway | NOT_RUN | not executed |
| specialist-provenance | NOT_RUN | not executed |
| specialist-learning-fairness | NOT_RUN | not executed |
| specialist-evaluation | NOT_RUN | not executed |
| evaluation-budget | NOT_RUN | not executed |
| evaluation-adapter | NOT_RUN | not executed |
| evaluation-orchestration | NOT_RUN | not executed |
| evaluation-independent-review | NOT_RUN | not executed |
| evaluation-commercial-market | NOT_RUN | not executed |
| evaluation-commercial-profitability | NOT_RUN | not executed |
| evaluation-commercial-suppliers | NOT_RUN | not executed |
| migration-upgrade-rollback | NOT_RUN | not executed |
| specialist-restart-prepare | NOT_RUN | not executed |
| evaluation-restart-prepare | NOT_RUN | not executed |
| postgres-restart | NOT_RUN | not executed |
| migration-after-restart | NOT_RUN | not executed |
| specialist-restart-check | NOT_RUN | not executed |
| evaluation-restart-check | NOT_RUN | not executed |
| phase0-migrations | NOT_RUN | not executed |
| phase0-acceptance | NOT_RUN | not executed |
| phase0-postgres | NOT_RUN | not executed |
| tenant-isolation | NOT_RUN | not executed |
| fail-closed-security | NOT_RUN | not executed |
| clean-image | NOT_RUN | not executed |
| image-contract | NOT_RUN | not executed |
| application-startup-restart | NOT_RUN | not executed |
| source-integrity | NOT_RUN | not executed |
| cleanup | PASS | [log](logs/56-cleanup.log) |

## Unresolved defects / blockers

- contracts: exit 1 (see logs/16-contracts.log)

## Excluded checks

- GitHub-hosted execution and effective merge governance: SKIP — Not performed; account restriction and rules remain external gates
- Staging, production, live providers, paid model calls and customer data: SKIP — Outside authorization; no readiness claim

## Runtime versions

```json
{
  "node": "v22.23.4",
  "npm": "10.9.9",
  "openssl": "OpenSSL 3.0.22 25 Aug 2026 (Library: OpenSSL 3.0.22 25 Aug 2026)",
  "python": "Python 3.11.17",
  "postgres": "PostgreSQL 15.19 (Debian 15.19-1.pgdg12+2) on x86_64-pc-linux-gnu, compiled by gcc (Debian 12.2.0-14+deb12u1) 12.2.0, 64-bit",
  "actionlint": "1.7.7\ninstalled by downloading from release page\nbuilt with go1.23.4 compiler for linux/amd64"
}
```

## Container images

- node: `node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2`; ID `sha256:eefceac94552a7e7e9da532feb53139a8630e3934b862662ce1d7cb877772c86`
- productionBase: `node:22-alpine@sha256:ce8d97f7cfc7c5386421eb932df20a29df99b1a7f469f6157d5c9956702ffadc`; ID `sha256:c79227476e31e0f5410cfc4578f1f9a59300510491f2f6f0b5eaf956dbef4986`
- postgres: `pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9`; ID `sha256:4b4956e2ab1f0aec9779dfca20366a9963a3f24c34269c3a115dd838387f0734`
- python: `python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8`; ID `sha256:b4403f3b7acf5e0700a5dd4e7ab01456d62b557a208a04f8a42d3470d93b5730`

## Commands and suite outcomes

### preflight — PASS

2026-10-22T14:51:37.726Z → 2026-10-22T14:51:38.078Z

```sh
git rev-parse HEAD
```
Exit: 0; signal: none; 2026-10-22T14:51:37.730Z → 2026-10-22T14:51:37.735Z

```sh
git rev-parse 'HEAD^{tree}'
```
Exit: 0; signal: none; 2026-10-22T14:51:37.736Z → 2026-10-22T14:51:37.739Z

```sh
git status --porcelain=v1 --untracked-files=normal
```
Exit: 0; signal: none; 2026-10-22T14:51:37.739Z → 2026-10-22T14:51:37.744Z

```sh
docker context inspect
```
Exit: 0; signal: none; 2026-10-22T14:51:37.744Z → 2026-10-22T14:51:37.758Z

```sh
docker version --format '{{json .}}'
```
Exit: 0; signal: none; 2026-10-22T14:51:37.758Z → 2026-10-22T14:51:37.780Z

```sh
docker compose version --short
```
Exit: 0; signal: none; 2026-10-22T14:51:37.780Z → 2026-10-22T14:51:37.882Z

```sh
docker buildx version
```
Exit: 0; signal: none; 2026-10-22T14:51:37.882Z → 2026-10-22T14:51:37.994Z

```sh
docker info --format '{{.OSType}}/{{.Architecture}}'
```
Exit: 0; signal: none; 2026-10-22T14:51:37.994Z → 2026-10-22T14:51:38.050Z

```sh
git --version
```
Exit: 0; signal: none; 2026-10-22T14:51:38.050Z → 2026-10-22T14:51:38.053Z

```sh
curl --version
```
Exit: 0; signal: none; 2026-10-22T14:51:38.053Z → 2026-10-22T14:51:38.076Z

```sh
tar --version
```
Exit: 0; signal: none; 2026-10-22T14:51:38.076Z → 2026-10-22T14:51:38.078Z


### snapshot — PASS

2026-10-22T14:51:38.080Z → 2026-10-22T14:51:38.147Z

```sh
git archive --format=tar --output /tmp/sam-verify-hfl1za/source.tar 9d131f1aba410659ef304cbdbcb49382c7daa1f6
```
Exit: 0; signal: none; 2026-10-22T14:51:38.082Z → 2026-10-22T14:51:38.113Z

```sh
tar -xf /tmp/sam-verify-hfl1za/source.tar -C /tmp/sam-verify-hfl1za/source
```
Exit: 0; signal: none; 2026-10-22T14:51:38.113Z → 2026-10-22T14:51:38.123Z


### images — PASS

2026-10-22T14:51:38.149Z → 2026-10-22T14:51:38.262Z

```sh
docker image inspect node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2
```
Exit: 0; signal: none; 2026-10-22T14:51:38.150Z → 2026-10-22T14:51:38.164Z

```sh
docker image inspect node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2
```
Exit: 0; signal: none; 2026-10-22T14:51:38.164Z → 2026-10-22T14:51:38.178Z

```sh
docker image inspect node:22-alpine@sha256:ce8d97f7cfc7c5386421eb932df20a29df99b1a7f469f6157d5c9956702ffadc
```
Exit: 0; signal: none; 2026-10-22T14:51:38.178Z → 2026-10-22T14:51:38.194Z

```sh
docker image inspect node:22-alpine@sha256:ce8d97f7cfc7c5386421eb932df20a29df99b1a7f469f6157d5c9956702ffadc
```
Exit: 0; signal: none; 2026-10-22T14:51:38.194Z → 2026-10-22T14:51:38.210Z

```sh
docker image inspect pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9
```
Exit: 0; signal: none; 2026-10-22T14:51:38.210Z → 2026-10-22T14:51:38.222Z

```sh
docker image inspect pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9
```
Exit: 0; signal: none; 2026-10-22T14:51:38.222Z → 2026-10-22T14:51:38.236Z

```sh
docker image inspect python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8
```
Exit: 0; signal: none; 2026-10-22T14:51:38.236Z → 2026-10-22T14:51:38.250Z

```sh
docker image inspect python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8
```
Exit: 0; signal: none; 2026-10-22T14:51:38.250Z → 2026-10-22T14:51:38.262Z


### isolated-postgres — PASS

2026-10-22T14:51:38.263Z → 2026-10-22T14:51:46.043Z

```sh
docker network create --internal --label sam.verification.run=sam-verify-1792680697724-d2fa742e sam-verify-1792680697724-d2fa742e-net
```
Exit: 0; signal: none; 2026-10-22T14:51:38.265Z → 2026-10-22T14:51:38.300Z

```sh
docker run --detach --name sam-verify-1792680697724-d2fa742e-pg --label sam.verification.run=sam-verify-1792680697724-d2fa742e --network sam-verify-1792680697724-d2fa742e-net --env POSTGRES_DB=sam_core_test --env POSTGRES_PASSWORD=verification-fixture pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9
```
Exit: 0; signal: none; 2026-10-22T14:51:38.300Z → 2026-10-22T14:51:44.215Z

```sh
docker exec sam-verify-1792680697724-d2fa742e-pg pg_isready -U postgres -d sam_core_test
```
Exit: 2; signal: none; 2026-10-22T14:51:44.215Z → 2026-10-22T14:51:44.312Z

```sh
docker exec sam-verify-1792680697724-d2fa742e-pg pg_isready -U postgres -d sam_core_test
```
Exit: 2; signal: none; 2026-10-22T14:51:44.813Z → 2026-10-22T14:51:44.911Z

```sh
docker exec sam-verify-1792680697724-d2fa742e-pg pg_isready -U postgres -d sam_core_test
```
Exit: 0; signal: none; 2026-10-22T14:51:45.412Z → 2026-10-22T14:51:45.501Z

```sh
docker exec sam-verify-1792680697724-d2fa742e-pg psql -U postgres -d sam_core_test -v ON_ERROR_STOP=1 -c 'CREATE DATABASE sam_core_test_lifecycle'
```
Exit: 0; signal: none; 2026-10-22T14:51:45.501Z → 2026-10-22T14:51:45.647Z

```sh
docker exec sam-verify-1792680697724-d2fa742e-pg psql -U postgres -d sam_core_test -v ON_ERROR_STOP=1 -c 'CREATE DATABASE sam_core_test_application'
```
Exit: 0; signal: none; 2026-10-22T14:51:45.647Z → 2026-10-22T14:51:45.857Z

```sh
docker exec sam-verify-1792680697724-d2fa742e-pg psql -U postgres -d sam_core_test -v ON_ERROR_STOP=1 -c 'CREATE DATABASE sam_greenfield'
```
Exit: 0; signal: none; 2026-10-22T14:51:45.857Z → 2026-10-22T14:51:46.043Z


### node-dependencies — PASS

2026-10-22T14:51:46.051Z → 2026-10-22T14:52:06.007Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-1 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env HTTP_PROXY --env HTTPS_PROXY --env NO_PROXY --env http_proxy --env https_proxy --env no_proxy --add-host proxy:172.31.3.13 --mount type=bind,src=/usr/local/share/ca-certificates/environment-proxy-ca.crt,dst=/tmp/verification-ca.pem,readonly --env NODE_EXTRA_CA_CERTS=/tmp/verification-ca.pem --env PIP_CERT=/tmp/verification-ca.pem node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm ci --include=dev --cache /tmp/npm-cache --fetch-retries=1 --fetch-timeout=20000
```
Exit: 0; signal: none; 2026-10-22T14:51:46.053Z → 2026-10-22T14:52:06.007Z


### python-dependencies — PASS

2026-10-22T14:52:06.012Z → 2026-10-22T14:52:11.178Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-2 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env HTTP_PROXY --env HTTPS_PROXY --env NO_PROXY --env http_proxy --env https_proxy --env no_proxy --add-host proxy:172.31.3.13 --mount type=bind,src=/usr/local/share/ca-certificates/environment-proxy-ca.crt,dst=/tmp/verification-ca.pem,readonly --env NODE_EXTRA_CA_CERTS=/tmp/verification-ca.pem --env PIP_CERT=/tmp/verification-ca.pem --mount type=bind,src=/tmp/sam-verify-hfl1za/python,dst=/fixtures python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8 python -m pip install --target /fixtures/site --cache-dir /tmp/pip-cache --retries 1 --timeout 20 --only-binary=:all: --require-hashes --requirement scripts/testing/requirements-verification.txt
```
Exit: 0; signal: none; 2026-10-22T14:52:06.015Z → 2026-10-22T14:52:11.178Z


### runtime-versions — PASS

2026-10-22T14:52:11.181Z → 2026-10-22T14:52:56.743Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-3 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node --version
```
Exit: 0; signal: none; 2026-10-22T14:52:11.183Z → 2026-10-22T14:52:23.661Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-4 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm --version
```
Exit: 0; signal: none; 2026-10-22T14:52:23.661Z → 2026-10-22T14:52:38.118Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-5 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 openssl version
```
Exit: 0; signal: none; 2026-10-22T14:52:38.119Z → 2026-10-22T14:52:53.509Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-6 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8 python --version
```
Exit: 0; signal: none; 2026-10-22T14:52:53.510Z → 2026-10-22T14:52:56.598Z

```sh
docker exec sam-verify-1792680697724-d2fa742e-pg psql -U postgres -d sam_core_test -Atc 'SELECT version()'
```
Exit: 0; signal: none; 2026-10-22T14:52:56.598Z → 2026-10-22T14:52:56.743Z


### workflow-tool — PASS

2026-10-22T14:52:56.746Z → 2026-10-22T14:52:57.438Z

```sh
curl --fail --location --silent --show-error --max-time 60 --output /tmp/sam-verify-hfl1za/actionlint.tar.gz https://github.com/rhysd/actionlint/releases/download/v1.7.7/actionlint_1.7.7_linux_amd64.tar.gz
```
Exit: 0; signal: none; 2026-10-22T14:52:56.749Z → 2026-10-22T14:52:57.312Z

```sh
tar -xzf /tmp/sam-verify-hfl1za/actionlint.tar.gz -C /tmp/sam-verify-hfl1za actionlint
```
Exit: 0; signal: none; 2026-10-22T14:52:57.326Z → 2026-10-22T14:52:57.433Z

```sh
/tmp/sam-verify-hfl1za/actionlint --version
```
Exit: 0; signal: none; 2026-10-22T14:52:57.433Z → 2026-10-22T14:52:57.438Z


### workflow-validation — PASS

2026-10-22T14:52:57.442Z → 2026-10-22T14:52:57.460Z

```sh
/tmp/sam-verify-hfl1za/actionlint -no-color -shellcheck= -pyflakes= .github/workflows/phase0-postgres-verification.yml
```
Exit: 0; signal: none; 2026-10-22T14:52:57.448Z → 2026-10-22T14:52:57.460Z


### configuration-validation — PASS

2026-10-22T14:52:57.464Z → 2026-10-22T14:53:46.176Z

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node tests/testing/runner-contract.cjs
```
Exit: 0; signal: none; 2026-10-22T14:52:57.467Z → 2026-10-22T14:52:58.024Z

```sh
docker compose --file docker-compose.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:52:58.026Z → 2026-10-22T14:52:58.326Z

```sh
docker compose --file docker-compose.production.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:52:58.327Z → 2026-10-22T14:52:58.543Z

```sh
docker compose --file deploy/production/docker-compose.live.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:52:58.543Z → 2026-10-22T14:52:58.756Z

```sh
docker compose --file deploy/staging/docker-compose.integration.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:52:58.756Z → 2026-10-22T14:52:58.947Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-7 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node tests/release/build_configuration.cjs
```
Exit: 0; signal: none; 2026-10-22T14:52:58.947Z → 2026-10-22T14:53:17.246Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-8 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node tests/release/preparation.cjs
```
Exit: 0; signal: none; 2026-10-22T14:53:17.247Z → 2026-10-22T14:53:31.167Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-9 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node packages/db/src/migrate.js --check-deterministic
```
Exit: 0; signal: none; 2026-10-22T14:53:31.167Z → 2026-10-22T14:53:46.176Z


### typecheck — PASS

2026-10-22T14:53:46.180Z → 2026-10-22T14:54:05.628Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-10 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm run typecheck
```
Exit: 0; signal: none; 2026-10-22T14:53:46.183Z → 2026-10-22T14:54:05.628Z


### regression — PASS

2026-10-22T14:54:05.630Z → 2026-10-22T14:54:49.765Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-11 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=9d131f1aba410659ef304cbdbcb49382c7daa1f6 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm run test:core-regression
```
Exit: 0; signal: none; 2026-10-22T14:54:05.634Z → 2026-10-22T14:54:49.763Z

- tests/phase1/final_acceptance.ts: PASS; 2026-10-22T14:54:18.202Z → 2026-10-22T14:54:18.753Z
- tests/phase1/full_vertical_slice.ts: PASS; 2026-10-22T14:54:18.775Z → 2026-10-22T14:54:19.234Z
- tests/phase1/kernel_smoke.ts: PASS; 2026-10-22T14:54:19.252Z → 2026-10-22T14:54:19.712Z
- tests/phase1/replan_recovery.ts: PASS; 2026-10-22T14:54:19.730Z → 2026-10-22T14:54:20.171Z
- tests/phase1/runtime_loop.ts: PASS; 2026-10-22T14:54:20.189Z → 2026-10-22T14:54:20.712Z
- tests/phase2/authority_guard.ts: PASS; 2026-10-22T14:54:20.754Z → 2026-10-22T14:54:21.328Z
- tests/phase2/brain_kernel_handoff.ts: PASS; 2026-10-22T14:54:21.371Z → 2026-10-22T14:54:22.023Z
- tests/phase2/brain_replanning.ts: PASS; 2026-10-22T14:54:22.065Z → 2026-10-22T14:54:22.743Z
- tests/phase2/final_acceptance.ts: PASS; 2026-10-22T14:54:22.761Z → 2026-10-22T14:54:23.267Z
- tests/phase2/gateway_resilience.ts: PASS; 2026-10-22T14:54:23.284Z → 2026-10-22T14:54:23.727Z
- tests/phase2/model_gateway.ts: PASS; 2026-10-22T14:54:23.744Z → 2026-10-22T14:54:24.179Z
- tests/phase3/capability_catalog.ts: PASS; 2026-10-22T14:54:24.196Z → 2026-10-22T14:54:24.526Z
- tests/phase3/final_acceptance.ts: PASS; 2026-10-22T14:54:24.545Z → 2026-10-22T14:54:25.051Z
- tests/phase3/specialist_delegation.ts: PASS; 2026-10-22T14:54:25.069Z → 2026-10-22T14:54:25.477Z
- tests/phase3/specialist_supervisor.ts: PASS; 2026-10-22T14:54:25.493Z → 2026-10-22T14:54:25.924Z
- tests/phase4/reconciliation.ts: PASS; 2026-10-22T14:54:25.948Z → 2026-10-22T14:54:26.463Z
- tests/phase4/tool_gateway.ts: PASS; 2026-10-22T14:54:26.483Z → 2026-10-22T14:54:27.039Z
- tests/phase5/final_acceptance.ts: PASS; 2026-10-22T14:54:27.056Z → 2026-10-22T14:54:27.541Z
- tests/phase5/verified_learning.ts: PASS; 2026-10-22T14:54:27.558Z → 2026-10-22T14:54:27.998Z
- tests/phase6/final_acceptance.ts: PASS; 2026-10-22T14:54:28.015Z → 2026-10-22T14:54:28.418Z
- tests/phase6/operational_supervision.ts: PASS; 2026-10-22T14:54:28.435Z → 2026-10-22T14:54:28.842Z
- tests/phase6/policy_evaluation.ts: PASS; 2026-10-22T14:54:28.861Z → 2026-10-22T14:54:29.179Z
- tests/phase7/production_readiness.ts: PASS; 2026-10-22T14:54:29.196Z → 2026-10-22T14:54:29.683Z
- tests/phase7/runtime_module_loading.ts: PASS; 2026-10-22T14:54:29.701Z → 2026-10-22T14:54:31.167Z
- tests/phase7/runtime_service.ts: PASS; 2026-10-22T14:54:31.186Z → 2026-10-22T14:54:31.765Z
- tests/phase8/chatgpt_tool_surface.ts: PASS; 2026-10-22T14:54:31.782Z → 2026-10-22T14:54:32.191Z
- tests/phase9/production_wiring.ts: PASS; 2026-10-22T14:54:32.208Z → 2026-10-22T14:54:32.904Z
- tests/phase10/mcp_transport.ts: PASS; 2026-10-22T14:54:32.936Z → 2026-10-22T14:54:34.064Z
- tests/phase11/model_adapters.ts: PASS; 2026-10-22T14:54:34.085Z → 2026-10-22T14:54:34.785Z
- tests/phase12/gmail_adapter.ts: PASS; 2026-10-22T14:54:34.807Z → 2026-10-22T14:54:35.305Z
- tests/phase12/gmail_read_trial.ts: PASS; 2026-10-22T14:54:35.326Z → 2026-10-22T14:54:36.074Z
- tests/phase13/drive_adapters.ts: PASS; 2026-10-22T14:54:36.092Z → 2026-10-22T14:54:36.591Z
- tests/phase14/eboekhouden_read.ts: PASS; 2026-10-22T14:54:36.607Z → 2026-10-22T14:54:37.067Z
- tests/phase15/bol_read.ts: PASS; 2026-10-22T14:54:37.083Z → 2026-10-22T14:54:37.528Z
- tests/phase16/bol_operational_intelligence.ts: PASS; 2026-10-22T14:54:37.544Z → 2026-10-22T14:54:38.011Z
- tests/phase17/bol_sam_surface.ts: PASS; 2026-10-22T14:54:38.027Z → 2026-10-22T14:54:38.670Z
- tests/phase17/finance_reconciliation.ts: PASS; 2026-10-22T14:54:38.687Z → 2026-10-22T14:54:39.181Z
- tests/phase18/operational_finance_loop.ts: PASS; 2026-10-22T14:54:39.198Z → 2026-10-22T14:54:39.687Z
- tests/phase19/command_center.ts: PASS; 2026-10-22T14:54:39.703Z → 2026-10-22T14:54:40.186Z
- tests/phase20/live_golden_chain_gate.ts: PASS; 2026-10-22T14:54:40.203Z → 2026-10-22T14:54:40.688Z
- tests/phase21/mcp_internal_oauth.ts: PASS; 2026-10-22T14:54:40.705Z → 2026-10-22T14:54:41.736Z
- tests/phase21/production_deployment.ts: PASS; 2026-10-22T14:54:41.753Z → 2026-10-22T14:54:42.127Z
- tests/phase22/acceptance_recovery.ts: PASS; 2026-10-22T14:54:42.144Z → 2026-10-22T14:54:43.420Z
- tests/phase22/bol_analysis.ts: PASS; 2026-10-22T14:54:43.437Z → 2026-10-22T14:54:43.926Z
- tests/phase22/bol_analysis_bridge.ts: PASS; 2026-10-22T14:54:43.943Z → 2026-10-22T14:54:44.499Z
- tests/phase22/planner_scope.ts: PASS; 2026-10-22T14:54:44.516Z → 2026-10-22T14:54:46.176Z
- tests/phase22/runtime_recovery.ts: PASS; 2026-10-22T14:54:46.202Z → 2026-10-22T14:54:47.414Z
- tests/phase22/submit_goal_planner.ts: PASS; 2026-10-22T14:54:47.431Z → 2026-10-22T14:54:48.109Z
- tests/phase22/submit_goal_surface.ts: PASS; 2026-10-22T14:54:48.138Z → 2026-10-22T14:54:48.957Z

### core-reliability — PASS

2026-10-22T14:54:49.769Z → 2026-10-22T14:55:17.344Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-12 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=9d131f1aba410659ef304cbdbcb49382c7daa1f6 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm run test:core-reliability
```
Exit: 0; signal: none; 2026-10-22T14:54:49.772Z → 2026-10-22T14:55:17.341Z

- tests/core/reliability.ts: PASS; 2026-10-22T14:55:04.614Z → 2026-10-22T14:55:10.266Z
- tests/core/planningConcurrency.ts: PASS; 2026-10-22T14:55:10.294Z → 2026-10-22T14:55:10.918Z
- tests/core/reservationRace.ts: PASS; 2026-10-22T14:55:10.936Z → 2026-10-22T14:55:11.396Z
- tests/core/tenantWorkload.ts: PASS; 2026-10-22T14:55:11.413Z → 2026-10-22T14:55:11.947Z
- tests/core/eventBacklog.ts: PASS; 2026-10-22T14:55:11.965Z → 2026-10-22T14:55:13.675Z
- tests/core/learningScheduling.ts: PASS; 2026-10-22T14:55:13.695Z → 2026-10-22T14:55:14.194Z
- tests/core/startupAdmission.ts: PASS; 2026-10-22T14:55:14.211Z → 2026-10-22T14:55:15.932Z
- tests/core/planningDeadline.ts: PASS; 2026-10-22T14:55:15.951Z → 2026-10-22T14:55:16.596Z

### provider-auth — PASS

2026-10-22T14:55:17.350Z → 2026-10-22T14:55:29.789Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-13 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=9d131f1aba410659ef304cbdbcb49382c7daa1f6 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/provider_auth.ts
```
Exit: 0; signal: none; 2026-10-22T14:55:17.355Z → 2026-10-22T14:55:29.789Z

- tests/release/provider_auth.ts: PASS; 2026-10-22T14:55:28.703Z → 2026-10-22T14:55:29.084Z

### postgres-tls — PASS

2026-10-22T14:55:29.792Z → 2026-10-22T14:55:43.729Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-14 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=9d131f1aba410659ef304cbdbcb49382c7daa1f6 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/postgres_tls.ts
```
Exit: 0; signal: none; 2026-10-22T14:55:29.796Z → 2026-10-22T14:55:43.729Z

- tests/release/postgres_tls.ts: PASS; 2026-10-22T14:55:42.362Z → 2026-10-22T14:55:43.032Z

### contracts — FAIL

2026-10-22T14:55:43.733Z → 2026-10-22T14:55:58.520Z

```sh
docker run --rm --name sam-verify-1792680697724-d2fa742e-job-15 --label sam.verification.run=sam-verify-1792680697724-d2fa742e --init --network container:sam-verify-1792680697724-d2fa742e-pg --mount type=bind,src=/tmp/sam-verify-hfl1za/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=9d131f1aba410659ef304cbdbcb49382c7daa1f6 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/contracts.ts
```
Exit: 1; signal: none; 2026-10-22T14:55:43.736Z → 2026-10-22T14:55:58.520Z


### synthetic-pilot — NOT_RUN

not started → not completed


### managed-schema — NOT_RUN

not started → not completed


### local-bundle — NOT_RUN

not started → not completed


### closed-setup — NOT_RUN

not started → not completed


### database-contract — NOT_RUN

not started → not completed


### prelaunch-gate — NOT_RUN

not started → not completed


### render-migration-compatibility — NOT_RUN

not started → not completed


### render-google-oauth-contracts — NOT_RUN

not started → not completed


### integration-migrations — NOT_RUN

not started → not completed


### integration-oauth-mcp — NOT_RUN

not started → not completed


### integration-orchestration — NOT_RUN

not started → not completed


### specialist-reasoning — NOT_RUN

not started → not completed


### specialist-gateway — NOT_RUN

not started → not completed


### specialist-provenance — NOT_RUN

not started → not completed


### specialist-learning-fairness — NOT_RUN

not started → not completed


### specialist-evaluation — NOT_RUN

not started → not completed


### evaluation-budget — NOT_RUN

not started → not completed


### evaluation-adapter — NOT_RUN

not started → not completed


### evaluation-orchestration — NOT_RUN

not started → not completed


### evaluation-independent-review — NOT_RUN

not started → not completed


### evaluation-commercial-market — NOT_RUN

not started → not completed


### evaluation-commercial-profitability — NOT_RUN

not started → not completed


### evaluation-commercial-suppliers — NOT_RUN

not started → not completed


### migration-upgrade-rollback — NOT_RUN

not started → not completed


### specialist-restart-prepare — NOT_RUN

not started → not completed


### evaluation-restart-prepare — NOT_RUN

not started → not completed


### postgres-restart — NOT_RUN

not started → not completed


### migration-after-restart — NOT_RUN

not started → not completed


### specialist-restart-check — NOT_RUN

not started → not completed


### evaluation-restart-check — NOT_RUN

not started → not completed


### phase0-migrations — NOT_RUN

not started → not completed


### phase0-acceptance — NOT_RUN

not started → not completed


### phase0-postgres — NOT_RUN

not started → not completed


### tenant-isolation — NOT_RUN

not started → not completed


### fail-closed-security — NOT_RUN

not started → not completed


### clean-image — NOT_RUN

not started → not completed


### image-contract — NOT_RUN

not started → not completed


### application-startup-restart — NOT_RUN

not started → not completed


### source-integrity — NOT_RUN

not started → not completed


### cleanup — PASS

2026-10-22T14:55:58.525Z → 2026-10-22T14:55:59.579Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-pg
```
Exit: 0; signal: none; 2026-10-22T14:55:58.529Z → 2026-10-22T14:55:58.548Z

```sh
docker rm --force --volumes sam-verify-1792680697724-d2fa742e-pg
```
Exit: 0; signal: none; 2026-10-22T14:55:58.548Z → 2026-10-22T14:55:59.091Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-1
```
Exit: 1; signal: none; 2026-10-22T14:55:59.091Z → 2026-10-22T14:55:59.141Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-2
```
Exit: 1; signal: none; 2026-10-22T14:55:59.142Z → 2026-10-22T14:55:59.165Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-3
```
Exit: 1; signal: none; 2026-10-22T14:55:59.166Z → 2026-10-22T14:55:59.193Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-4
```
Exit: 1; signal: none; 2026-10-22T14:55:59.193Z → 2026-10-22T14:55:59.223Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-5
```
Exit: 1; signal: none; 2026-10-22T14:55:59.223Z → 2026-10-22T14:55:59.250Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-6
```
Exit: 1; signal: none; 2026-10-22T14:55:59.250Z → 2026-10-22T14:55:59.279Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-7
```
Exit: 1; signal: none; 2026-10-22T14:55:59.279Z → 2026-10-22T14:55:59.305Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-8
```
Exit: 1; signal: none; 2026-10-22T14:55:59.305Z → 2026-10-22T14:55:59.329Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-9
```
Exit: 1; signal: none; 2026-10-22T14:55:59.329Z → 2026-10-22T14:55:59.349Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-10
```
Exit: 1; signal: none; 2026-10-22T14:55:59.349Z → 2026-10-22T14:55:59.370Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-11
```
Exit: 1; signal: none; 2026-10-22T14:55:59.370Z → 2026-10-22T14:55:59.394Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-12
```
Exit: 1; signal: none; 2026-10-22T14:55:59.395Z → 2026-10-22T14:55:59.415Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-13
```
Exit: 1; signal: none; 2026-10-22T14:55:59.415Z → 2026-10-22T14:55:59.436Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-14
```
Exit: 1; signal: none; 2026-10-22T14:55:59.436Z → 2026-10-22T14:55:59.459Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-job-15
```
Exit: 1; signal: none; 2026-10-22T14:55:59.459Z → 2026-10-22T14:55:59.478Z

```sh
docker network inspect --format '{{index .Labels "sam.verification.run"}}' sam-verify-1792680697724-d2fa742e-net
```
Exit: 0; signal: none; 2026-10-22T14:55:59.478Z → 2026-10-22T14:55:59.492Z

```sh
docker network rm sam-verify-1792680697724-d2fa742e-net
```
Exit: 0; signal: none; 2026-10-22T14:55:59.492Z → 2026-10-22T14:55:59.547Z


Exact structured commands, suite results and evidence hashes: [report.json](report.json).
No GitHub status was posted. A local pass cannot satisfy a required hosted check or authorize merge/deployment.
