# Independent SAM verification

Status: **FAIL**
Source: `c2454d24c7db72be21948b03dbadc64bc2a83243` (clean: true)
Started: 2026-10-22T14:57:42.113Z; completed: 2026-10-22T15:03:51.620Z

INDEPENDENT_LOCAL_SYNTHETIC_ACCEPTANCE_NOT_HOSTED_OR_PRODUCTION

| Check | Result | Log |
| --- | --- | --- |
| preflight | PASS | [log](logs/01-preflight.log) |
| snapshot | PASS | [log](logs/02-snapshot.log) |
| images | PASS | [log](logs/03-images.log) |
| isolated-postgres | PASS | [log](logs/04-isolated-postgres.log) |
| node-dependencies | PASS | [log](logs/05-node-dependencies.log) |
| python-dependencies | PASS | [log](logs/06-python-dependencies.log) |
| runtime-versions | PASS | [log](logs/07-runtime-versions.log) |
| workflow-tool | PASS | [log](logs/08-workflow-tool.log) |
| workflow-validation | PASS | [log](logs/09-workflow-validation.log) |
| configuration-validation | PASS | [log](logs/10-configuration-validation.log) |
| typecheck | PASS | [log](logs/11-typecheck.log) |
| regression | PASS | [log](logs/12-regression.log) |
| core-reliability | PASS | [log](logs/13-core-reliability.log) |
| provider-auth | PASS | [log](logs/14-provider-auth.log) |
| postgres-tls | PASS | [log](logs/15-postgres-tls.log) |
| contracts | PASS | [log](logs/16-contracts.log) |
| synthetic-pilot | PASS | [log](logs/17-synthetic-pilot.log) |
| managed-schema | PASS | [log](logs/18-managed-schema.log) |
| local-bundle | PASS | [log](logs/19-local-bundle.log) |
| closed-setup | PASS | [log](logs/20-closed-setup.log) |
| database-contract | PASS | [log](logs/21-database-contract.log) |
| prelaunch-gate | PASS | [log](logs/22-prelaunch-gate.log) |
| render-migration-compatibility | PASS | [log](logs/23-render-migration-compatibility.log) |
| render-google-oauth-contracts | FAIL | [log](logs/24-render-google-oauth-contracts.log) |
| integration-migrations | NOT_RUN | not executed |
| integration-oauth-mcp | NOT_RUN | not executed |
| integration-orchestration | NOT_RUN | not executed |
| specialist-reasoning | NOT_RUN | not executed |
| specialist-gateway | NOT_RUN | not executed |
| specialist-provenance | NOT_RUN | not executed |
| specialist-learning-fairness | NOT_RUN | not executed |
| specialist-evaluation | NOT_RUN | not executed |
| evaluation-budget | NOT_RUN | not executed |
| evaluation-adapter | NOT_RUN | not executed |
| evaluation-orchestration | NOT_RUN | not executed |
| evaluation-independent-review | NOT_RUN | not executed |
| evaluation-commercial-market | NOT_RUN | not executed |
| evaluation-commercial-profitability | NOT_RUN | not executed |
| evaluation-commercial-suppliers | NOT_RUN | not executed |
| migration-upgrade-rollback | NOT_RUN | not executed |
| specialist-restart-prepare | NOT_RUN | not executed |
| evaluation-restart-prepare | NOT_RUN | not executed |
| postgres-restart | NOT_RUN | not executed |
| migration-after-restart | NOT_RUN | not executed |
| specialist-restart-check | NOT_RUN | not executed |
| evaluation-restart-check | NOT_RUN | not executed |
| phase0-migrations | NOT_RUN | not executed |
| phase0-acceptance | NOT_RUN | not executed |
| phase0-postgres | NOT_RUN | not executed |
| tenant-isolation | NOT_RUN | not executed |
| fail-closed-security | NOT_RUN | not executed |
| clean-image | NOT_RUN | not executed |
| image-contract | NOT_RUN | not executed |
| application-startup-restart | NOT_RUN | not executed |
| source-integrity | NOT_RUN | not executed |
| cleanup | PASS | [log](logs/56-cleanup.log) |

## Unresolved defects / blockers

- render-google-oauth-contracts: exit 1 (see logs/24-render-google-oauth-contracts.log)

## Excluded checks

- GitHub-hosted execution and effective merge governance: SKIP — Not performed; account restriction and rules remain external gates
- Staging, production, live providers, paid model calls and customer data: SKIP — Outside authorization; no readiness claim

## Runtime versions

```json
{
  "node": "v22.23.4",
  "npm": "10.9.9",
  "openssl": "OpenSSL 3.0.22 25 Aug 2026 (Library: OpenSSL 3.0.22 25 Aug 2026)",
  "python": "Python 3.11.17",
  "postgres": "PostgreSQL 15.19 (Debian 15.19-1.pgdg12+2) on x86_64-pc-linux-gnu, compiled by gcc (Debian 12.2.0-14+deb12u1) 12.2.0, 64-bit",
  "actionlint": "1.7.7\ninstalled by downloading from release page\nbuilt with go1.23.4 compiler for linux/amd64"
}
```

## Container images

- node: `node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2`; ID `sha256:eefceac94552a7e7e9da532feb53139a8630e3934b862662ce1d7cb877772c86`
- productionBase: `node:22-alpine@sha256:ce8d97f7cfc7c5386421eb932df20a29df99b1a7f469f6157d5c9956702ffadc`; ID `sha256:c79227476e31e0f5410cfc4578f1f9a59300510491f2f6f0b5eaf956dbef4986`
- postgres: `pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9`; ID `sha256:4b4956e2ab1f0aec9779dfca20366a9963a3f24c34269c3a115dd838387f0734`
- python: `python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8`; ID `sha256:b4403f3b7acf5e0700a5dd4e7ab01456d62b557a208a04f8a42d3470d93b5730`

## Commands and suite outcomes

### preflight — PASS

2026-10-22T14:57:42.115Z → 2026-10-22T14:57:42.505Z

```sh
git rev-parse HEAD
```
Exit: 0; signal: none; 2026-10-22T14:57:42.119Z → 2026-10-22T14:57:42.127Z

```sh
git rev-parse 'HEAD^{tree}'
```
Exit: 0; signal: none; 2026-10-22T14:57:42.127Z → 2026-10-22T14:57:42.130Z

```sh
git status --porcelain=v1 --untracked-files=normal
```
Exit: 0; signal: none; 2026-10-22T14:57:42.130Z → 2026-10-22T14:57:42.138Z

```sh
docker context inspect
```
Exit: 0; signal: none; 2026-10-22T14:57:42.138Z → 2026-10-22T14:57:42.154Z

```sh
docker version --format '{{json .}}'
```
Exit: 0; signal: none; 2026-10-22T14:57:42.154Z → 2026-10-22T14:57:42.178Z

```sh
docker compose version --short
```
Exit: 0; signal: none; 2026-10-22T14:57:42.178Z → 2026-10-22T14:57:42.294Z

```sh
docker buildx version
```
Exit: 0; signal: none; 2026-10-22T14:57:42.294Z → 2026-10-22T14:57:42.418Z

```sh
docker info --format '{{.OSType}}/{{.Architecture}}'
```
Exit: 0; signal: none; 2026-10-22T14:57:42.418Z → 2026-10-22T14:57:42.475Z

```sh
git --version
```
Exit: 0; signal: none; 2026-10-22T14:57:42.475Z → 2026-10-22T14:57:42.478Z

```sh
curl --version
```
Exit: 0; signal: none; 2026-10-22T14:57:42.478Z → 2026-10-22T14:57:42.502Z

```sh
tar --version
```
Exit: 0; signal: none; 2026-10-22T14:57:42.502Z → 2026-10-22T14:57:42.505Z


### snapshot — PASS

2026-10-22T14:57:42.507Z → 2026-10-22T14:57:42.585Z

```sh
git archive --format=tar --output /tmp/sam-verify-oJH0De/source.tar c2454d24c7db72be21948b03dbadc64bc2a83243
```
Exit: 0; signal: none; 2026-10-22T14:57:42.509Z → 2026-10-22T14:57:42.544Z

```sh
tar -xf /tmp/sam-verify-oJH0De/source.tar -C /tmp/sam-verify-oJH0De/source
```
Exit: 0; signal: none; 2026-10-22T14:57:42.544Z → 2026-10-22T14:57:42.554Z


### images — PASS

2026-10-22T14:57:42.587Z → 2026-10-22T14:57:42.719Z

```sh
docker image inspect node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2
```
Exit: 0; signal: none; 2026-10-22T14:57:42.588Z → 2026-10-22T14:57:42.604Z

```sh
docker image inspect node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2
```
Exit: 0; signal: none; 2026-10-22T14:57:42.604Z → 2026-10-22T14:57:42.619Z

```sh
docker image inspect node:22-alpine@sha256:ce8d97f7cfc7c5386421eb932df20a29df99b1a7f469f6157d5c9956702ffadc
```
Exit: 0; signal: none; 2026-10-22T14:57:42.619Z → 2026-10-22T14:57:42.634Z

```sh
docker image inspect node:22-alpine@sha256:ce8d97f7cfc7c5386421eb932df20a29df99b1a7f469f6157d5c9956702ffadc
```
Exit: 0; signal: none; 2026-10-22T14:57:42.634Z → 2026-10-22T14:57:42.651Z

```sh
docker image inspect pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9
```
Exit: 0; signal: none; 2026-10-22T14:57:42.651Z → 2026-10-22T14:57:42.673Z

```sh
docker image inspect pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9
```
Exit: 0; signal: none; 2026-10-22T14:57:42.673Z → 2026-10-22T14:57:42.687Z

```sh
docker image inspect python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8
```
Exit: 0; signal: none; 2026-10-22T14:57:42.687Z → 2026-10-22T14:57:42.706Z

```sh
docker image inspect python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8
```
Exit: 0; signal: none; 2026-10-22T14:57:42.706Z → 2026-10-22T14:57:42.719Z


### isolated-postgres — PASS

2026-10-22T14:57:42.721Z → 2026-10-22T14:57:51.737Z

```sh
docker network create --internal --label sam.verification.run=sam-verify-1792681062113-5a78c922 sam-verify-1792681062113-5a78c922-net
```
Exit: 0; signal: none; 2026-10-22T14:57:42.722Z → 2026-10-22T14:57:42.761Z

```sh
docker run --detach --name sam-verify-1792681062113-5a78c922-pg --label sam.verification.run=sam-verify-1792681062113-5a78c922 --network sam-verify-1792681062113-5a78c922-net --env POSTGRES_DB=sam_core_test --env POSTGRES_PASSWORD=verification-fixture pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9
```
Exit: 0; signal: none; 2026-10-22T14:57:42.761Z → 2026-10-22T14:57:49.193Z

```sh
docker exec sam-verify-1792681062113-5a78c922-pg pg_isready -U postgres -d sam_core_test
```
Exit: 2; signal: none; 2026-10-22T14:57:49.193Z → 2026-10-22T14:57:49.288Z

```sh
docker exec sam-verify-1792681062113-5a78c922-pg pg_isready -U postgres -d sam_core_test
```
Exit: 2; signal: none; 2026-10-22T14:57:49.796Z → 2026-10-22T14:57:50.010Z

```sh
docker exec sam-verify-1792681062113-5a78c922-pg pg_isready -U postgres -d sam_core_test
```
Exit: 2; signal: none; 2026-10-22T14:57:50.519Z → 2026-10-22T14:57:50.649Z

```sh
docker exec sam-verify-1792681062113-5a78c922-pg pg_isready -U postgres -d sam_core_test
```
Exit: 0; signal: none; 2026-10-22T14:57:51.157Z → 2026-10-22T14:57:51.292Z

```sh
docker exec sam-verify-1792681062113-5a78c922-pg psql -U postgres -d sam_core_test -v ON_ERROR_STOP=1 -c 'CREATE DATABASE sam_core_test_lifecycle'
```
Exit: 0; signal: none; 2026-10-22T14:57:51.292Z → 2026-10-22T14:57:51.431Z

```sh
docker exec sam-verify-1792681062113-5a78c922-pg psql -U postgres -d sam_core_test -v ON_ERROR_STOP=1 -c 'CREATE DATABASE sam_core_test_application'
```
Exit: 0; signal: none; 2026-10-22T14:57:51.431Z → 2026-10-22T14:57:51.578Z

```sh
docker exec sam-verify-1792681062113-5a78c922-pg psql -U postgres -d sam_core_test -v ON_ERROR_STOP=1 -c 'CREATE DATABASE sam_greenfield'
```
Exit: 0; signal: none; 2026-10-22T14:57:51.579Z → 2026-10-22T14:57:51.737Z


### node-dependencies — PASS

2026-10-22T14:57:51.745Z → 2026-10-22T14:58:09.852Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-1 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env HTTP_PROXY --env HTTPS_PROXY --env NO_PROXY --env http_proxy --env https_proxy --env no_proxy --add-host proxy:172.31.3.13 --mount type=bind,src=/usr/local/share/ca-certificates/environment-proxy-ca.crt,dst=/tmp/verification-ca.pem,readonly --env NODE_EXTRA_CA_CERTS=/tmp/verification-ca.pem --env PIP_CERT=/tmp/verification-ca.pem node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm ci --include=dev --cache /tmp/npm-cache --fetch-retries=1 --fetch-timeout=20000
```
Exit: 0; signal: none; 2026-10-22T14:57:51.748Z → 2026-10-22T14:58:09.852Z


### python-dependencies — PASS

2026-10-22T14:58:09.857Z → 2026-10-22T14:58:15.084Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-2 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env HTTP_PROXY --env HTTPS_PROXY --env NO_PROXY --env http_proxy --env https_proxy --env no_proxy --add-host proxy:172.31.3.13 --mount type=bind,src=/usr/local/share/ca-certificates/environment-proxy-ca.crt,dst=/tmp/verification-ca.pem,readonly --env NODE_EXTRA_CA_CERTS=/tmp/verification-ca.pem --env PIP_CERT=/tmp/verification-ca.pem --mount type=bind,src=/tmp/sam-verify-oJH0De/python,dst=/fixtures python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8 python -m pip install --target /fixtures/site --cache-dir /tmp/pip-cache --retries 1 --timeout 20 --only-binary=:all: --require-hashes --requirement scripts/testing/requirements-verification.txt
```
Exit: 0; signal: none; 2026-10-22T14:58:09.860Z → 2026-10-22T14:58:15.084Z


### runtime-versions — PASS

2026-10-22T14:58:15.086Z → 2026-10-22T14:58:56.727Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-3 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node --version
```
Exit: 0; signal: none; 2026-10-22T14:58:15.088Z → 2026-10-22T14:58:26.070Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-4 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm --version
```
Exit: 0; signal: none; 2026-10-22T14:58:26.070Z → 2026-10-22T14:58:40.233Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-5 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 openssl version
```
Exit: 0; signal: none; 2026-10-22T14:58:40.234Z → 2026-10-22T14:58:54.252Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-6 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8 python --version
```
Exit: 0; signal: none; 2026-10-22T14:58:54.252Z → 2026-10-22T14:58:56.620Z

```sh
docker exec sam-verify-1792681062113-5a78c922-pg psql -U postgres -d sam_core_test -Atc 'SELECT version()'
```
Exit: 0; signal: none; 2026-10-22T14:58:56.620Z → 2026-10-22T14:58:56.727Z


### workflow-tool — PASS

2026-10-22T14:58:56.730Z → 2026-10-22T14:58:57.111Z

```sh
curl --fail --location --silent --show-error --max-time 60 --output /tmp/sam-verify-oJH0De/actionlint.tar.gz https://github.com/rhysd/actionlint/releases/download/v1.7.7/actionlint_1.7.7_linux_amd64.tar.gz
```
Exit: 0; signal: none; 2026-10-22T14:58:56.733Z → 2026-10-22T14:58:57.062Z

```sh
tar -xzf /tmp/sam-verify-oJH0De/actionlint.tar.gz -C /tmp/sam-verify-oJH0De actionlint
```
Exit: 0; signal: none; 2026-10-22T14:58:57.064Z → 2026-10-22T14:58:57.107Z

```sh
/tmp/sam-verify-oJH0De/actionlint --version
```
Exit: 0; signal: none; 2026-10-22T14:58:57.107Z → 2026-10-22T14:58:57.111Z


### workflow-validation — PASS

2026-10-22T14:58:57.112Z → 2026-10-22T14:58:57.118Z

```sh
/tmp/sam-verify-oJH0De/actionlint -no-color -shellcheck= -pyflakes= .github/workflows/phase0-postgres-verification.yml
```
Exit: 0; signal: none; 2026-10-22T14:58:57.115Z → 2026-10-22T14:58:57.118Z


### configuration-validation — PASS

2026-10-22T14:58:57.122Z → 2026-10-22T14:59:41.972Z

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node tests/testing/runner-contract.cjs
```
Exit: 0; signal: none; 2026-10-22T14:58:57.123Z → 2026-10-22T14:58:57.351Z

```sh
docker compose --file docker-compose.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:58:57.351Z → 2026-10-22T14:58:57.423Z

```sh
docker compose --file docker-compose.production.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:58:57.423Z → 2026-10-22T14:58:57.493Z

```sh
docker compose --file deploy/production/docker-compose.live.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:58:57.493Z → 2026-10-22T14:58:57.566Z

```sh
docker compose --file deploy/staging/docker-compose.integration.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:58:57.566Z → 2026-10-22T14:58:57.636Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-7 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node tests/release/build_configuration.cjs
```
Exit: 0; signal: none; 2026-10-22T14:58:57.636Z → 2026-10-22T14:59:13.248Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-8 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node tests/release/preparation.cjs
```
Exit: 0; signal: none; 2026-10-22T14:59:13.249Z → 2026-10-22T14:59:27.723Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-9 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node packages/db/src/migrate.js --check-deterministic
```
Exit: 0; signal: none; 2026-10-22T14:59:27.723Z → 2026-10-22T14:59:41.972Z


### typecheck — PASS

2026-10-22T14:59:41.976Z → 2026-10-22T15:00:01.578Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-10 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm run typecheck
```
Exit: 0; signal: none; 2026-10-22T14:59:41.980Z → 2026-10-22T15:00:01.578Z


### regression — PASS

2026-10-22T15:00:01.581Z → 2026-10-22T15:00:43.872Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-11 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm run test:core-regression
```
Exit: 0; signal: none; 2026-10-22T15:00:01.584Z → 2026-10-22T15:00:43.871Z

- tests/phase1/final_acceptance.ts: PASS; 2026-10-22T15:00:13.925Z → 2026-10-22T15:00:14.447Z
- tests/phase1/full_vertical_slice.ts: PASS; 2026-10-22T15:00:14.467Z → 2026-10-22T15:00:14.933Z
- tests/phase1/kernel_smoke.ts: PASS; 2026-10-22T15:00:14.950Z → 2026-10-22T15:00:15.392Z
- tests/phase1/replan_recovery.ts: PASS; 2026-10-22T15:00:15.409Z → 2026-10-22T15:00:15.855Z
- tests/phase1/runtime_loop.ts: PASS; 2026-10-22T15:00:15.872Z → 2026-10-22T15:00:16.333Z
- tests/phase2/authority_guard.ts: PASS; 2026-10-22T15:00:16.350Z → 2026-10-22T15:00:16.707Z
- tests/phase2/brain_kernel_handoff.ts: PASS; 2026-10-22T15:00:16.723Z → 2026-10-22T15:00:17.262Z
- tests/phase2/brain_replanning.ts: PASS; 2026-10-22T15:00:17.279Z → 2026-10-22T15:00:17.792Z
- tests/phase2/final_acceptance.ts: PASS; 2026-10-22T15:00:17.809Z → 2026-10-22T15:00:18.317Z
- tests/phase2/gateway_resilience.ts: PASS; 2026-10-22T15:00:18.333Z → 2026-10-22T15:00:18.783Z
- tests/phase2/model_gateway.ts: PASS; 2026-10-22T15:00:18.800Z → 2026-10-22T15:00:19.269Z
- tests/phase3/capability_catalog.ts: PASS; 2026-10-22T15:00:19.286Z → 2026-10-22T15:00:19.635Z
- tests/phase3/final_acceptance.ts: PASS; 2026-10-22T15:00:19.651Z → 2026-10-22T15:00:20.194Z
- tests/phase3/specialist_delegation.ts: PASS; 2026-10-22T15:00:20.210Z → 2026-10-22T15:00:20.654Z
- tests/phase3/specialist_supervisor.ts: PASS; 2026-10-22T15:00:20.671Z → 2026-10-22T15:00:21.092Z
- tests/phase4/reconciliation.ts: PASS; 2026-10-22T15:00:21.109Z → 2026-10-22T15:00:21.616Z
- tests/phase4/tool_gateway.ts: PASS; 2026-10-22T15:00:21.632Z → 2026-10-22T15:00:22.128Z
- tests/phase5/final_acceptance.ts: PASS; 2026-10-22T15:00:22.145Z → 2026-10-22T15:00:22.631Z
- tests/phase5/verified_learning.ts: PASS; 2026-10-22T15:00:22.647Z → 2026-10-22T15:00:23.130Z
- tests/phase6/final_acceptance.ts: PASS; 2026-10-22T15:00:23.147Z → 2026-10-22T15:00:23.557Z
- tests/phase6/operational_supervision.ts: PASS; 2026-10-22T15:00:23.574Z → 2026-10-22T15:00:23.963Z
- tests/phase6/policy_evaluation.ts: PASS; 2026-10-22T15:00:23.980Z → 2026-10-22T15:00:24.304Z
- tests/phase7/production_readiness.ts: PASS; 2026-10-22T15:00:24.320Z → 2026-10-22T15:00:24.861Z
- tests/phase7/runtime_module_loading.ts: PASS; 2026-10-22T15:00:24.878Z → 2026-10-22T15:00:26.404Z
- tests/phase7/runtime_service.ts: PASS; 2026-10-22T15:00:26.422Z → 2026-10-22T15:00:27.038Z
- tests/phase8/chatgpt_tool_surface.ts: PASS; 2026-10-22T15:00:27.060Z → 2026-10-22T15:00:27.589Z
- tests/phase9/production_wiring.ts: PASS; 2026-10-22T15:00:27.606Z → 2026-10-22T15:00:28.245Z
- tests/phase10/mcp_transport.ts: PASS; 2026-10-22T15:00:28.262Z → 2026-10-22T15:00:29.109Z
- tests/phase11/model_adapters.ts: PASS; 2026-10-22T15:00:29.127Z → 2026-10-22T15:00:29.612Z
- tests/phase12/gmail_adapter.ts: PASS; 2026-10-22T15:00:29.629Z → 2026-10-22T15:00:30.090Z
- tests/phase12/gmail_read_trial.ts: PASS; 2026-10-22T15:00:30.107Z → 2026-10-22T15:00:30.887Z
- tests/phase13/drive_adapters.ts: PASS; 2026-10-22T15:00:30.904Z → 2026-10-22T15:00:31.399Z
- tests/phase14/eboekhouden_read.ts: PASS; 2026-10-22T15:00:31.415Z → 2026-10-22T15:00:31.884Z
- tests/phase15/bol_read.ts: PASS; 2026-10-22T15:00:31.901Z → 2026-10-22T15:00:32.364Z
- tests/phase16/bol_operational_intelligence.ts: PASS; 2026-10-22T15:00:32.381Z → 2026-10-22T15:00:32.854Z
- tests/phase17/bol_sam_surface.ts: PASS; 2026-10-22T15:00:32.871Z → 2026-10-22T15:00:33.499Z
- tests/phase17/finance_reconciliation.ts: PASS; 2026-10-22T15:00:33.515Z → 2026-10-22T15:00:33.970Z
- tests/phase18/operational_finance_loop.ts: PASS; 2026-10-22T15:00:33.987Z → 2026-10-22T15:00:34.478Z
- tests/phase19/command_center.ts: PASS; 2026-10-22T15:00:34.495Z → 2026-10-22T15:00:34.978Z
- tests/phase20/live_golden_chain_gate.ts: PASS; 2026-10-22T15:00:34.995Z → 2026-10-22T15:00:35.497Z
- tests/phase21/mcp_internal_oauth.ts: PASS; 2026-10-22T15:00:35.514Z → 2026-10-22T15:00:36.581Z
- tests/phase21/production_deployment.ts: PASS; 2026-10-22T15:00:36.598Z → 2026-10-22T15:00:36.963Z
- tests/phase22/acceptance_recovery.ts: PASS; 2026-10-22T15:00:36.980Z → 2026-10-22T15:00:38.267Z
- tests/phase22/bol_analysis.ts: PASS; 2026-10-22T15:00:38.284Z → 2026-10-22T15:00:38.777Z
- tests/phase22/bol_analysis_bridge.ts: PASS; 2026-10-22T15:00:38.794Z → 2026-10-22T15:00:39.378Z
- tests/phase22/planner_scope.ts: PASS; 2026-10-22T15:00:39.396Z → 2026-10-22T15:00:40.066Z
- tests/phase22/runtime_recovery.ts: PASS; 2026-10-22T15:00:40.083Z → 2026-10-22T15:00:40.924Z
- tests/phase22/submit_goal_planner.ts: PASS; 2026-10-22T15:00:40.941Z → 2026-10-22T15:00:42.200Z
- tests/phase22/submit_goal_surface.ts: PASS; 2026-10-22T15:00:42.229Z → 2026-10-22T15:00:43.000Z

### core-reliability — PASS

2026-10-22T15:00:43.874Z → 2026-10-22T15:01:06.492Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-12 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm run test:core-reliability
```
Exit: 0; signal: none; 2026-10-22T15:00:43.877Z → 2026-10-22T15:01:06.492Z

- tests/core/reliability.ts: PASS; 2026-10-22T15:00:54.210Z → 2026-10-22T15:00:59.401Z
- tests/core/planningConcurrency.ts: PASS; 2026-10-22T15:00:59.423Z → 2026-10-22T15:00:59.977Z
- tests/core/reservationRace.ts: PASS; 2026-10-22T15:00:59.995Z → 2026-10-22T15:01:00.453Z
- tests/core/tenantWorkload.ts: PASS; 2026-10-22T15:01:00.470Z → 2026-10-22T15:01:01.034Z
- tests/core/eventBacklog.ts: PASS; 2026-10-22T15:01:01.052Z → 2026-10-22T15:01:02.893Z
- tests/core/learningScheduling.ts: PASS; 2026-10-22T15:01:02.912Z → 2026-10-22T15:01:03.401Z
- tests/core/startupAdmission.ts: PASS; 2026-10-22T15:01:03.418Z → 2026-10-22T15:01:05.099Z
- tests/core/planningDeadline.ts: PASS; 2026-10-22T15:01:05.120Z → 2026-10-22T15:01:05.757Z

### provider-auth — PASS

2026-10-22T15:01:06.495Z → 2026-10-22T15:01:18.601Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-13 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/provider_auth.ts
```
Exit: 0; signal: none; 2026-10-22T15:01:06.497Z → 2026-10-22T15:01:18.601Z

- tests/release/provider_auth.ts: PASS; 2026-10-22T15:01:17.525Z → 2026-10-22T15:01:17.929Z

### postgres-tls — PASS

2026-10-22T15:01:18.604Z → 2026-10-22T15:01:31.012Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-14 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/postgres_tls.ts
```
Exit: 0; signal: none; 2026-10-22T15:01:18.608Z → 2026-10-22T15:01:31.010Z

- tests/release/postgres_tls.ts: PASS; 2026-10-22T15:01:29.675Z → 2026-10-22T15:01:30.339Z

### contracts — PASS

2026-10-22T15:01:31.017Z → 2026-10-22T15:01:45.713Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-15 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/contracts.ts
```
Exit: 0; signal: none; 2026-10-22T15:01:31.020Z → 2026-10-22T15:01:45.713Z

- tests/release/contracts.ts: PASS; 2026-10-22T15:01:44.001Z → 2026-10-22T15:01:44.720Z

### synthetic-pilot — PASS

2026-10-22T15:01:45.723Z → 2026-10-22T15:01:59.317Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-16 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/synthetic_pilot.ts
```
Exit: 0; signal: none; 2026-10-22T15:01:45.727Z → 2026-10-22T15:01:59.317Z

- tests/release/synthetic_pilot.ts: PASS; 2026-10-22T15:01:57.753Z → 2026-10-22T15:01:58.529Z

### managed-schema — PASS

2026-10-22T15:01:59.323Z → 2026-10-22T15:02:11.488Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-17 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/managed_schema_source.cjs
```
Exit: 0; signal: none; 2026-10-22T15:01:59.326Z → 2026-10-22T15:02:11.488Z

- tests/release/managed_schema_source.cjs: PASS; 2026-10-22T15:02:10.539Z → 2026-10-22T15:02:10.784Z

### local-bundle — PASS

2026-10-22T15:02:11.493Z → 2026-10-22T15:02:23.886Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-18 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/local_bundle.ts
```
Exit: 0; signal: none; 2026-10-22T15:02:11.495Z → 2026-10-22T15:02:23.885Z

- tests/release/local_bundle.ts: PASS; 2026-10-22T15:02:22.763Z → 2026-10-22T15:02:23.156Z

### closed-setup — PASS

2026-10-22T15:02:23.891Z → 2026-10-22T15:02:39.467Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-19 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/setup.ts
```
Exit: 0; signal: none; 2026-10-22T15:02:23.894Z → 2026-10-22T15:02:39.466Z

- tests/release/setup.ts: PASS; 2026-10-22T15:02:38.113Z → 2026-10-22T15:02:38.707Z

### database-contract — PASS

2026-10-22T15:02:39.473Z → 2026-10-22T15:02:53.068Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-20 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/database_check.ts
```
Exit: 0; signal: none; 2026-10-22T15:02:39.476Z → 2026-10-22T15:02:53.067Z

- tests/release/database_check.ts: PASS; 2026-10-22T15:02:51.995Z → 2026-10-22T15:02:52.359Z

### prelaunch-gate — PASS

2026-10-22T15:02:53.073Z → 2026-10-22T15:03:09.330Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-21 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/release/prelaunch.ts
```
Exit: 0; signal: none; 2026-10-22T15:02:53.076Z → 2026-10-22T15:03:09.329Z

- tests/release/prelaunch.ts: PASS; 2026-10-22T15:03:08.108Z → 2026-10-22T15:03:08.473Z

### render-migration-compatibility — PASS

2026-10-22T15:03:09.337Z → 2026-10-22T15:03:27.302Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-22 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=c2454d24c7db72be21948b03dbadc64bc2a83243 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node scripts/testing/core-reliability.cjs --suite tests/compatibility/renderMigrations.ts
```
Exit: 0; signal: none; 2026-10-22T15:03:09.340Z → 2026-10-22T15:03:27.301Z

- tests/compatibility/renderMigrations.ts: PASS; 2026-10-22T15:03:25.287Z → 2026-10-22T15:03:26.530Z

### render-google-oauth-contracts — FAIL

2026-10-22T15:03:27.307Z → 2026-10-22T15:03:50.328Z

```sh
docker run --rm --name sam-verify-1792681062113-5a78c922-job-23 --label sam.verification.run=sam-verify-1792681062113-5a78c922 --init --network container:sam-verify-1792681062113-5a78c922-pg --mount type=bind,src=/tmp/sam-verify-oJH0De/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env NODE_ENV=test --env DATABASE_URL=postgres://fixture:fixture@127.0.0.1:9/sam_core_test node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node --import tsx --test tests/isolated/sam_google_bundle.ts tests/isolated/sam_google_evidence.ts tests/isolated/sam_google_http.ts tests/isolated/sam_google_mcp_bridge.ts tests/isolated/sam_google_oauth_flow.ts tests/isolated/sam_google_oauth_pkce.ts tests/isolated/sam_google_oauth_state.ts tests/isolated/sam_google_postgres.ts tests/isolated/sam_google_recovery.ts tests/isolated/sam_google_review.ts tests/isolated/sam_google_token_crypto.ts tests/isolated/sam_google_verifier_claim.ts tests/phase21/mcp_internal_oauth.ts tests/phase22/submit_goal_surface.ts
```
Exit: 1; signal: none; 2026-10-22T15:03:27.312Z → 2026-10-22T15:03:50.326Z


### integration-migrations — NOT_RUN

not started → not completed


### integration-oauth-mcp — NOT_RUN

not started → not completed


### integration-orchestration — NOT_RUN

not started → not completed


### specialist-reasoning — NOT_RUN

not started → not completed


### specialist-gateway — NOT_RUN

not started → not completed


### specialist-provenance — NOT_RUN

not started → not completed


### specialist-learning-fairness — NOT_RUN

not started → not completed


### specialist-evaluation — NOT_RUN

not started → not completed


### evaluation-budget — NOT_RUN

not started → not completed


### evaluation-adapter — NOT_RUN

not started → not completed


### evaluation-orchestration — NOT_RUN

not started → not completed


### evaluation-independent-review — NOT_RUN

not started → not completed


### evaluation-commercial-market — NOT_RUN

not started → not completed


### evaluation-commercial-profitability — NOT_RUN

not started → not completed


### evaluation-commercial-suppliers — NOT_RUN

not started → not completed


### migration-upgrade-rollback — NOT_RUN

not started → not completed


### specialist-restart-prepare — NOT_RUN

not started → not completed


### evaluation-restart-prepare — NOT_RUN

not started → not completed


### postgres-restart — NOT_RUN

not started → not completed


### migration-after-restart — NOT_RUN

not started → not completed


### specialist-restart-check — NOT_RUN

not started → not completed


### evaluation-restart-check — NOT_RUN

not started → not completed


### phase0-migrations — NOT_RUN

not started → not completed


### phase0-acceptance — NOT_RUN

not started → not completed


### phase0-postgres — NOT_RUN

not started → not completed


### tenant-isolation — NOT_RUN

not started → not completed


### fail-closed-security — NOT_RUN

not started → not completed


### clean-image — NOT_RUN

not started → not completed


### image-contract — NOT_RUN

not started → not completed


### application-startup-restart — NOT_RUN

not started → not completed


### source-integrity — NOT_RUN

not started → not completed


### cleanup — PASS

2026-10-22T15:03:50.337Z → 2026-10-22T15:03:51.615Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-pg
```
Exit: 0; signal: none; 2026-10-22T15:03:50.344Z → 2026-10-22T15:03:50.372Z

```sh
docker rm --force --volumes sam-verify-1792681062113-5a78c922-pg
```
Exit: 0; signal: none; 2026-10-22T15:03:50.372Z → 2026-10-22T15:03:50.938Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-1
```
Exit: 1; signal: none; 2026-10-22T15:03:50.938Z → 2026-10-22T15:03:50.970Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-2
```
Exit: 1; signal: none; 2026-10-22T15:03:50.971Z → 2026-10-22T15:03:51.003Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-3
```
Exit: 1; signal: none; 2026-10-22T15:03:51.003Z → 2026-10-22T15:03:51.031Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-4
```
Exit: 1; signal: none; 2026-10-22T15:03:51.031Z → 2026-10-22T15:03:51.063Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-5
```
Exit: 1; signal: none; 2026-10-22T15:03:51.063Z → 2026-10-22T15:03:51.084Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-6
```
Exit: 1; signal: none; 2026-10-22T15:03:51.084Z → 2026-10-22T15:03:51.107Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-7
```
Exit: 1; signal: none; 2026-10-22T15:03:51.107Z → 2026-10-22T15:03:51.137Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-8
```
Exit: 1; signal: none; 2026-10-22T15:03:51.137Z → 2026-10-22T15:03:51.160Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-9
```
Exit: 1; signal: none; 2026-10-22T15:03:51.160Z → 2026-10-22T15:03:51.181Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-10
```
Exit: 1; signal: none; 2026-10-22T15:03:51.181Z → 2026-10-22T15:03:51.212Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-11
```
Exit: 1; signal: none; 2026-10-22T15:03:51.212Z → 2026-10-22T15:03:51.234Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-12
```
Exit: 1; signal: none; 2026-10-22T15:03:51.234Z → 2026-10-22T15:03:51.255Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-13
```
Exit: 1; signal: none; 2026-10-22T15:03:51.255Z → 2026-10-22T15:03:51.275Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-14
```
Exit: 1; signal: none; 2026-10-22T15:03:51.276Z → 2026-10-22T15:03:51.297Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-15
```
Exit: 1; signal: none; 2026-10-22T15:03:51.297Z → 2026-10-22T15:03:51.319Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-16
```
Exit: 1; signal: none; 2026-10-22T15:03:51.319Z → 2026-10-22T15:03:51.340Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-17
```
Exit: 1; signal: none; 2026-10-22T15:03:51.340Z → 2026-10-22T15:03:51.362Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-18
```
Exit: 1; signal: none; 2026-10-22T15:03:51.362Z → 2026-10-22T15:03:51.387Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-19
```
Exit: 1; signal: none; 2026-10-22T15:03:51.387Z → 2026-10-22T15:03:51.408Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-20
```
Exit: 1; signal: none; 2026-10-22T15:03:51.408Z → 2026-10-22T15:03:51.428Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-21
```
Exit: 1; signal: none; 2026-10-22T15:03:51.428Z → 2026-10-22T15:03:51.451Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-22
```
Exit: 1; signal: none; 2026-10-22T15:03:51.451Z → 2026-10-22T15:03:51.476Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-job-23
```
Exit: 1; signal: none; 2026-10-22T15:03:51.476Z → 2026-10-22T15:03:51.497Z

```sh
docker network inspect --format '{{index .Labels "sam.verification.run"}}' sam-verify-1792681062113-5a78c922-net
```
Exit: 0; signal: none; 2026-10-22T15:03:51.497Z → 2026-10-22T15:03:51.510Z

```sh
docker network rm sam-verify-1792681062113-5a78c922-net
```
Exit: 0; signal: none; 2026-10-22T15:03:51.510Z → 2026-10-22T15:03:51.569Z


Exact structured commands, suite results and evidence hashes: [report.json](report.json).
No GitHub status was posted. A local pass cannot satisfy a required hosted check or authorize merge/deployment.
