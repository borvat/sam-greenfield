# Independent SAM verification

Status: **FAIL**
Source: `160dd9b694f739f40d31e25a209b7daf6fb962e6` (clean: true)
Started: 2026-10-22T14:46:30.994Z; completed: 2026-10-22T14:49:31.208Z

INDEPENDENT_LOCAL_SYNTHETIC_ACCEPTANCE_NOT_HOSTED_OR_PRODUCTION

| Check | Result | Log |
| --- | --- | --- |
| preflight | PASS | [log](logs/01-preflight.log) |
| snapshot | PASS | [log](logs/02-snapshot.log) |
| images | PASS | [log](logs/03-images.log) |
| isolated-postgres | PASS | [log](logs/04-isolated-postgres.log) |
| node-dependencies | PASS | [log](logs/05-node-dependencies.log) |
| python-dependencies | PASS | [log](logs/06-python-dependencies.log) |
| runtime-versions | PASS | [log](logs/07-runtime-versions.log) |
| workflow-tool | PASS | [log](logs/08-workflow-tool.log) |
| workflow-validation | PASS | [log](logs/09-workflow-validation.log) |
| configuration-validation | PASS | [log](logs/10-configuration-validation.log) |
| typecheck | PASS | [log](logs/11-typecheck.log) |
| regression | PASS | [log](logs/12-regression.log) |
| core-reliability | FAIL | [log](logs/13-core-reliability.log) |
| provider-auth | NOT_RUN | not executed |
| postgres-tls | NOT_RUN | not executed |
| contracts | NOT_RUN | not executed |
| synthetic-pilot | NOT_RUN | not executed |
| managed-schema | NOT_RUN | not executed |
| local-bundle | NOT_RUN | not executed |
| closed-setup | NOT_RUN | not executed |
| database-contract | NOT_RUN | not executed |
| prelaunch-gate | NOT_RUN | not executed |
| render-migration-compatibility | NOT_RUN | not executed |
| render-google-oauth-contracts | NOT_RUN | not executed |
| integration-migrations | NOT_RUN | not executed |
| integration-oauth-mcp | NOT_RUN | not executed |
| integration-orchestration | NOT_RUN | not executed |
| specialist-reasoning | NOT_RUN | not executed |
| specialist-gateway | NOT_RUN | not executed |
| specialist-provenance | NOT_RUN | not executed |
| specialist-learning-fairness | NOT_RUN | not executed |
| specialist-evaluation | NOT_RUN | not executed |
| evaluation-budget | NOT_RUN | not executed |
| evaluation-adapter | NOT_RUN | not executed |
| evaluation-orchestration | NOT_RUN | not executed |
| evaluation-independent-review | NOT_RUN | not executed |
| evaluation-commercial-market | NOT_RUN | not executed |
| evaluation-commercial-profitability | NOT_RUN | not executed |
| evaluation-commercial-suppliers | NOT_RUN | not executed |
| migration-upgrade-rollback | NOT_RUN | not executed |
| specialist-restart-prepare | NOT_RUN | not executed |
| evaluation-restart-prepare | NOT_RUN | not executed |
| postgres-restart | NOT_RUN | not executed |
| migration-after-restart | NOT_RUN | not executed |
| specialist-restart-check | NOT_RUN | not executed |
| evaluation-restart-check | NOT_RUN | not executed |
| phase0-migrations | NOT_RUN | not executed |
| phase0-acceptance | NOT_RUN | not executed |
| phase0-postgres | NOT_RUN | not executed |
| tenant-isolation | NOT_RUN | not executed |
| fail-closed-security | NOT_RUN | not executed |
| clean-image | NOT_RUN | not executed |
| image-contract | NOT_RUN | not executed |
| application-startup-restart | NOT_RUN | not executed |
| source-integrity | NOT_RUN | not executed |
| cleanup | PASS | [log](logs/56-cleanup.log) |

## Unresolved defects / blockers

- core-reliability: exit 1 (see logs/13-core-reliability.log)

## Excluded checks

- GitHub-hosted execution and effective merge governance: SKIP — Not performed; account restriction and rules remain external gates
- Staging, production, live providers, paid model calls and customer data: SKIP — Outside authorization; no readiness claim

## Runtime versions

```json
{
  "node": "v22.23.4",
  "npm": "10.9.9",
  "openssl": "OpenSSL 3.0.22 25 Aug 2026 (Library: OpenSSL 3.0.22 25 Aug 2026)",
  "python": "Python 3.11.17",
  "postgres": "PostgreSQL 15.19 (Debian 15.19-1.pgdg12+2) on x86_64-pc-linux-gnu, compiled by gcc (Debian 12.2.0-14+deb12u1) 12.2.0, 64-bit",
  "actionlint": "1.7.7\ninstalled by downloading from release page\nbuilt with go1.23.4 compiler for linux/amd64"
}
```

## Container images

- node: `node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2`; ID `sha256:eefceac94552a7e7e9da532feb53139a8630e3934b862662ce1d7cb877772c86`
- productionBase: `node:22-alpine@sha256:ce8d97f7cfc7c5386421eb932df20a29df99b1a7f469f6157d5c9956702ffadc`; ID `sha256:c79227476e31e0f5410cfc4578f1f9a59300510491f2f6f0b5eaf956dbef4986`
- postgres: `pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9`; ID `sha256:4b4956e2ab1f0aec9779dfca20366a9963a3f24c34269c3a115dd838387f0734`
- python: `python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8`; ID `sha256:b4403f3b7acf5e0700a5dd4e7ab01456d62b557a208a04f8a42d3470d93b5730`

## Commands and suite outcomes

### preflight — PASS

2026-10-22T14:46:30.995Z → 2026-10-22T14:46:31.442Z

```sh
git rev-parse HEAD
```
Exit: 0; signal: none; 2026-10-22T14:46:31.001Z → 2026-10-22T14:46:31.008Z

```sh
git rev-parse 'HEAD^{tree}'
```
Exit: 0; signal: none; 2026-10-22T14:46:31.008Z → 2026-10-22T14:46:31.011Z

```sh
git status --porcelain=v1 --untracked-files=normal
```
Exit: 0; signal: none; 2026-10-22T14:46:31.011Z → 2026-10-22T14:46:31.017Z

```sh
docker context inspect
```
Exit: 0; signal: none; 2026-10-22T14:46:31.017Z → 2026-10-22T14:46:31.068Z

```sh
docker version --format '{{json .}}'
```
Exit: 0; signal: none; 2026-10-22T14:46:31.068Z → 2026-10-22T14:46:31.115Z

```sh
docker compose version --short
```
Exit: 0; signal: none; 2026-10-22T14:46:31.115Z → 2026-10-22T14:46:31.228Z

```sh
docker buildx version
```
Exit: 0; signal: none; 2026-10-22T14:46:31.228Z → 2026-10-22T14:46:31.352Z

```sh
docker info --format '{{.OSType}}/{{.Architecture}}'
```
Exit: 0; signal: none; 2026-10-22T14:46:31.352Z → 2026-10-22T14:46:31.423Z

```sh
git --version
```
Exit: 0; signal: none; 2026-10-22T14:46:31.423Z → 2026-10-22T14:46:31.426Z

```sh
curl --version
```
Exit: 0; signal: none; 2026-10-22T14:46:31.427Z → 2026-10-22T14:46:31.439Z

```sh
tar --version
```
Exit: 0; signal: none; 2026-10-22T14:46:31.439Z → 2026-10-22T14:46:31.442Z


### snapshot — PASS

2026-10-22T14:46:31.443Z → 2026-10-22T14:46:31.588Z

```sh
git archive --format=tar --output /tmp/sam-verify-GL9r8P/source.tar 160dd9b694f739f40d31e25a209b7daf6fb962e6
```
Exit: 0; signal: none; 2026-10-22T14:46:31.447Z → 2026-10-22T14:46:31.507Z

```sh
tar -xf /tmp/sam-verify-GL9r8P/source.tar -C /tmp/sam-verify-GL9r8P/source
```
Exit: 0; signal: none; 2026-10-22T14:46:31.507Z → 2026-10-22T14:46:31.515Z


### images — PASS

2026-10-22T14:46:31.589Z → 2026-10-22T14:46:31.833Z

```sh
docker image inspect node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2
```
Exit: 0; signal: none; 2026-10-22T14:46:31.591Z → 2026-10-22T14:46:31.616Z

```sh
docker image inspect node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2
```
Exit: 0; signal: none; 2026-10-22T14:46:31.616Z → 2026-10-22T14:46:31.652Z

```sh
docker image inspect node:22-alpine@sha256:ce8d97f7cfc7c5386421eb932df20a29df99b1a7f469f6157d5c9956702ffadc
```
Exit: 0; signal: none; 2026-10-22T14:46:31.652Z → 2026-10-22T14:46:31.674Z

```sh
docker image inspect node:22-alpine@sha256:ce8d97f7cfc7c5386421eb932df20a29df99b1a7f469f6157d5c9956702ffadc
```
Exit: 0; signal: none; 2026-10-22T14:46:31.674Z → 2026-10-22T14:46:31.701Z

```sh
docker image inspect pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9
```
Exit: 0; signal: none; 2026-10-22T14:46:31.701Z → 2026-10-22T14:46:31.730Z

```sh
docker image inspect pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9
```
Exit: 0; signal: none; 2026-10-22T14:46:31.730Z → 2026-10-22T14:46:31.769Z

```sh
docker image inspect python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8
```
Exit: 0; signal: none; 2026-10-22T14:46:31.769Z → 2026-10-22T14:46:31.802Z

```sh
docker image inspect python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8
```
Exit: 0; signal: none; 2026-10-22T14:46:31.802Z → 2026-10-22T14:46:31.833Z


### isolated-postgres — PASS

2026-10-22T14:46:31.838Z → 2026-10-22T14:46:36.880Z

```sh
docker network create --internal --label sam.verification.run=sam-verify-1792680390993-81d5d06f sam-verify-1792680390993-81d5d06f-net
```
Exit: 0; signal: none; 2026-10-22T14:46:31.839Z → 2026-10-22T14:46:31.892Z

```sh
docker run --detach --name sam-verify-1792680390993-81d5d06f-pg --label sam.verification.run=sam-verify-1792680390993-81d5d06f --network sam-verify-1792680390993-81d5d06f-net --env POSTGRES_DB=sam_core_test --env POSTGRES_PASSWORD=verification-fixture pgvector/pgvector:pg15@sha256:47af0b65960b14f1c6945aa4ccae37836c632e9a6fe0eea9160936e616e5b2e9
```
Exit: 0; signal: none; 2026-10-22T14:46:31.892Z → 2026-10-22T14:46:35.219Z

```sh
docker exec sam-verify-1792680390993-81d5d06f-pg pg_isready -U postgres -d sam_core_test
```
Exit: 2; signal: none; 2026-10-22T14:46:35.219Z → 2026-10-22T14:46:35.311Z

```sh
docker exec sam-verify-1792680390993-81d5d06f-pg pg_isready -U postgres -d sam_core_test
```
Exit: 2; signal: none; 2026-10-22T14:46:35.814Z → 2026-10-22T14:46:35.919Z

```sh
docker exec sam-verify-1792680390993-81d5d06f-pg pg_isready -U postgres -d sam_core_test
```
Exit: 0; signal: none; 2026-10-22T14:46:36.420Z → 2026-10-22T14:46:36.513Z

```sh
docker exec sam-verify-1792680390993-81d5d06f-pg psql -U postgres -d sam_core_test -v ON_ERROR_STOP=1 -c 'CREATE DATABASE sam_core_test_lifecycle'
```
Exit: 0; signal: none; 2026-10-22T14:46:36.513Z → 2026-10-22T14:46:36.636Z

```sh
docker exec sam-verify-1792680390993-81d5d06f-pg psql -U postgres -d sam_core_test -v ON_ERROR_STOP=1 -c 'CREATE DATABASE sam_core_test_application'
```
Exit: 0; signal: none; 2026-10-22T14:46:36.636Z → 2026-10-22T14:46:36.758Z

```sh
docker exec sam-verify-1792680390993-81d5d06f-pg psql -U postgres -d sam_core_test -v ON_ERROR_STOP=1 -c 'CREATE DATABASE sam_greenfield'
```
Exit: 0; signal: none; 2026-10-22T14:46:36.758Z → 2026-10-22T14:46:36.880Z


### node-dependencies — PASS

2026-10-22T14:46:36.888Z → 2026-10-22T14:46:51.610Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-1 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env HTTP_PROXY --env HTTPS_PROXY --env NO_PROXY --env http_proxy --env https_proxy --env no_proxy --add-host proxy:172.31.3.13 --mount type=bind,src=/usr/local/share/ca-certificates/environment-proxy-ca.crt,dst=/tmp/verification-ca.pem,readonly --env NODE_EXTRA_CA_CERTS=/tmp/verification-ca.pem --env PIP_CERT=/tmp/verification-ca.pem node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm ci --include=dev --cache /tmp/npm-cache --fetch-retries=1 --fetch-timeout=20000
```
Exit: 0; signal: none; 2026-10-22T14:46:36.891Z → 2026-10-22T14:46:51.609Z


### python-dependencies — PASS

2026-10-22T14:46:51.617Z → 2026-10-22T14:46:56.745Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-2 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env HTTP_PROXY --env HTTPS_PROXY --env NO_PROXY --env http_proxy --env https_proxy --env no_proxy --add-host proxy:172.31.3.13 --mount type=bind,src=/usr/local/share/ca-certificates/environment-proxy-ca.crt,dst=/tmp/verification-ca.pem,readonly --env NODE_EXTRA_CA_CERTS=/tmp/verification-ca.pem --env PIP_CERT=/tmp/verification-ca.pem --mount type=bind,src=/tmp/sam-verify-GL9r8P/python,dst=/fixtures python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8 python -m pip install --target /fixtures/site --cache-dir /tmp/pip-cache --retries 1 --timeout 20 --only-binary=:all: --require-hashes --requirement scripts/testing/requirements-verification.txt
```
Exit: 0; signal: none; 2026-10-22T14:46:51.621Z → 2026-10-22T14:46:56.745Z


### runtime-versions — PASS

2026-10-22T14:46:56.748Z → 2026-10-22T14:47:32.183Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-3 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --network container:sam-verify-1792680390993-81d5d06f-pg --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node --version
```
Exit: 0; signal: none; 2026-10-22T14:46:56.751Z → 2026-10-22T14:47:10.508Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-4 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --network container:sam-verify-1792680390993-81d5d06f-pg --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm --version
```
Exit: 0; signal: none; 2026-10-22T14:47:10.509Z → 2026-10-22T14:47:21.211Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-5 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --network container:sam-verify-1792680390993-81d5d06f-pg --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 openssl version
```
Exit: 0; signal: none; 2026-10-22T14:47:21.212Z → 2026-10-22T14:47:30.691Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-6 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --network container:sam-verify-1792680390993-81d5d06f-pg --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp python:3.11-slim@sha256:cce12316475d7d56d605f76e1d811d0dc4e7227f2d4afd29951521264f504ff8 python --version
```
Exit: 0; signal: none; 2026-10-22T14:47:30.691Z → 2026-10-22T14:47:32.064Z

```sh
docker exec sam-verify-1792680390993-81d5d06f-pg psql -U postgres -d sam_core_test -Atc 'SELECT version()'
```
Exit: 0; signal: none; 2026-10-22T14:47:32.064Z → 2026-10-22T14:47:32.183Z


### workflow-tool — PASS

2026-10-22T14:47:32.186Z → 2026-10-22T14:47:32.530Z

```sh
curl --fail --location --silent --show-error --max-time 60 --output /tmp/sam-verify-GL9r8P/actionlint.tar.gz https://github.com/rhysd/actionlint/releases/download/v1.7.7/actionlint_1.7.7_linux_amd64.tar.gz
```
Exit: 0; signal: none; 2026-10-22T14:47:32.189Z → 2026-10-22T14:47:32.483Z

```sh
tar -xzf /tmp/sam-verify-GL9r8P/actionlint.tar.gz -C /tmp/sam-verify-GL9r8P actionlint
```
Exit: 0; signal: none; 2026-10-22T14:47:32.486Z → 2026-10-22T14:47:32.526Z

```sh
/tmp/sam-verify-GL9r8P/actionlint --version
```
Exit: 0; signal: none; 2026-10-22T14:47:32.526Z → 2026-10-22T14:47:32.530Z


### workflow-validation — PASS

2026-10-22T14:47:32.532Z → 2026-10-22T14:47:32.539Z

```sh
/tmp/sam-verify-GL9r8P/actionlint -no-color -shellcheck= -pyflakes= .github/workflows/phase0-postgres-verification.yml
```
Exit: 0; signal: none; 2026-10-22T14:47:32.535Z → 2026-10-22T14:47:32.539Z


### configuration-validation — PASS

2026-10-22T14:47:32.541Z → 2026-10-22T14:48:09.943Z

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node tests/testing/runner-contract.cjs
```
Exit: 0; signal: none; 2026-10-22T14:47:32.543Z → 2026-10-22T14:47:32.821Z

```sh
docker compose --file docker-compose.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:47:32.821Z → 2026-10-22T14:47:32.906Z

```sh
docker compose --file docker-compose.production.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:47:32.906Z → 2026-10-22T14:47:32.979Z

```sh
docker compose --file deploy/production/docker-compose.live.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:47:32.979Z → 2026-10-22T14:47:33.058Z

```sh
docker compose --file deploy/staging/docker-compose.integration.yml config --quiet --no-interpolate --no-env-resolution
```
Exit: 0; signal: none; 2026-10-22T14:47:33.058Z → 2026-10-22T14:47:33.136Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-7 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --network container:sam-verify-1792680390993-81d5d06f-pg --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node tests/release/build_configuration.cjs
```
Exit: 0; signal: none; 2026-10-22T14:47:33.136Z → 2026-10-22T14:47:44.585Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-8 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --network container:sam-verify-1792680390993-81d5d06f-pg --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node tests/release/preparation.cjs
```
Exit: 0; signal: none; 2026-10-22T14:47:44.586Z → 2026-10-22T14:47:57.612Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-9 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --network container:sam-verify-1792680390993-81d5d06f-pg --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 node packages/db/src/migrate.js --check-deterministic
```
Exit: 0; signal: none; 2026-10-22T14:47:57.612Z → 2026-10-22T14:48:09.943Z


### typecheck — PASS

2026-10-22T14:48:09.947Z → 2026-10-22T14:48:28.824Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-10 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --network container:sam-verify-1792680390993-81d5d06f-pg --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm run typecheck
```
Exit: 0; signal: none; 2026-10-22T14:48:09.951Z → 2026-10-22T14:48:28.824Z


### regression — PASS

2026-10-22T14:48:28.826Z → 2026-10-22T14:49:09.133Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-11 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --network container:sam-verify-1792680390993-81d5d06f-pg --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=160dd9b694f739f40d31e25a209b7daf6fb962e6 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm run test:core-regression
```
Exit: 0; signal: none; 2026-10-22T14:48:28.829Z → 2026-10-22T14:49:09.129Z

- tests/phase1/final_acceptance.ts: PASS; 2026-10-22T14:48:41.497Z → 2026-10-22T14:48:42.004Z
- tests/phase1/full_vertical_slice.ts: PASS; 2026-10-22T14:48:42.025Z → 2026-10-22T14:48:42.444Z
- tests/phase1/kernel_smoke.ts: PASS; 2026-10-22T14:48:42.461Z → 2026-10-22T14:48:42.898Z
- tests/phase1/replan_recovery.ts: PASS; 2026-10-22T14:48:42.915Z → 2026-10-22T14:48:43.338Z
- tests/phase1/runtime_loop.ts: PASS; 2026-10-22T14:48:43.354Z → 2026-10-22T14:48:43.754Z
- tests/phase2/authority_guard.ts: PASS; 2026-10-22T14:48:43.770Z → 2026-10-22T14:48:44.116Z
- tests/phase2/brain_kernel_handoff.ts: PASS; 2026-10-22T14:48:44.133Z → 2026-10-22T14:48:44.629Z
- tests/phase2/brain_replanning.ts: PASS; 2026-10-22T14:48:44.646Z → 2026-10-22T14:48:45.114Z
- tests/phase2/final_acceptance.ts: PASS; 2026-10-22T14:48:45.131Z → 2026-10-22T14:48:45.617Z
- tests/phase2/gateway_resilience.ts: PASS; 2026-10-22T14:48:45.634Z → 2026-10-22T14:48:46.049Z
- tests/phase2/model_gateway.ts: PASS; 2026-10-22T14:48:46.066Z → 2026-10-22T14:48:46.510Z
- tests/phase3/capability_catalog.ts: PASS; 2026-10-22T14:48:46.527Z → 2026-10-22T14:48:46.837Z
- tests/phase3/final_acceptance.ts: PASS; 2026-10-22T14:48:46.853Z → 2026-10-22T14:48:47.336Z
- tests/phase3/specialist_delegation.ts: PASS; 2026-10-22T14:48:47.353Z → 2026-10-22T14:48:47.730Z
- tests/phase3/specialist_supervisor.ts: PASS; 2026-10-22T14:48:47.746Z → 2026-10-22T14:48:48.127Z
- tests/phase4/reconciliation.ts: PASS; 2026-10-22T14:48:48.143Z → 2026-10-22T14:48:48.600Z
- tests/phase4/tool_gateway.ts: PASS; 2026-10-22T14:48:48.616Z → 2026-10-22T14:48:49.072Z
- tests/phase5/final_acceptance.ts: PASS; 2026-10-22T14:48:49.087Z → 2026-10-22T14:48:49.508Z
- tests/phase5/verified_learning.ts: PASS; 2026-10-22T14:48:49.524Z → 2026-10-22T14:48:49.961Z
- tests/phase6/final_acceptance.ts: PASS; 2026-10-22T14:48:49.978Z → 2026-10-22T14:48:50.367Z
- tests/phase6/operational_supervision.ts: PASS; 2026-10-22T14:48:50.384Z → 2026-10-22T14:48:50.758Z
- tests/phase6/policy_evaluation.ts: PASS; 2026-10-22T14:48:50.778Z → 2026-10-22T14:48:51.154Z
- tests/phase7/production_readiness.ts: PASS; 2026-10-22T14:48:51.171Z → 2026-10-22T14:48:51.591Z
- tests/phase7/runtime_module_loading.ts: PASS; 2026-10-22T14:48:51.607Z → 2026-10-22T14:48:52.955Z
- tests/phase7/runtime_service.ts: PASS; 2026-10-22T14:48:52.973Z → 2026-10-22T14:48:53.527Z
- tests/phase8/chatgpt_tool_surface.ts: PASS; 2026-10-22T14:48:53.543Z → 2026-10-22T14:48:53.948Z
- tests/phase9/production_wiring.ts: PASS; 2026-10-22T14:48:53.964Z → 2026-10-22T14:48:54.524Z
- tests/phase10/mcp_transport.ts: PASS; 2026-10-22T14:48:54.540Z → 2026-10-22T14:48:55.349Z
- tests/phase11/model_adapters.ts: PASS; 2026-10-22T14:48:55.365Z → 2026-10-22T14:48:55.796Z
- tests/phase12/gmail_adapter.ts: PASS; 2026-10-22T14:48:55.812Z → 2026-10-22T14:48:56.250Z
- tests/phase12/gmail_read_trial.ts: PASS; 2026-10-22T14:48:56.267Z → 2026-10-22T14:48:56.955Z
- tests/phase13/drive_adapters.ts: PASS; 2026-10-22T14:48:56.973Z → 2026-10-22T14:48:57.447Z
- tests/phase14/eboekhouden_read.ts: PASS; 2026-10-22T14:48:57.463Z → 2026-10-22T14:48:57.895Z
- tests/phase15/bol_read.ts: PASS; 2026-10-22T14:48:57.911Z → 2026-10-22T14:48:58.376Z
- tests/phase16/bol_operational_intelligence.ts: PASS; 2026-10-22T14:48:58.393Z → 2026-10-22T14:48:58.848Z
- tests/phase17/bol_sam_surface.ts: PASS; 2026-10-22T14:48:58.864Z → 2026-10-22T14:48:59.483Z
- tests/phase17/finance_reconciliation.ts: PASS; 2026-10-22T14:48:59.500Z → 2026-10-22T14:48:59.944Z
- tests/phase18/operational_finance_loop.ts: PASS; 2026-10-22T14:48:59.960Z → 2026-10-22T14:49:00.453Z
- tests/phase19/command_center.ts: PASS; 2026-10-22T14:49:00.469Z → 2026-10-22T14:49:00.955Z
- tests/phase20/live_golden_chain_gate.ts: PASS; 2026-10-22T14:49:00.972Z → 2026-10-22T14:49:01.464Z
- tests/phase21/mcp_internal_oauth.ts: PASS; 2026-10-22T14:49:01.480Z → 2026-10-22T14:49:02.525Z
- tests/phase21/production_deployment.ts: PASS; 2026-10-22T14:49:02.543Z → 2026-10-22T14:49:02.911Z
- tests/phase22/acceptance_recovery.ts: PASS; 2026-10-22T14:49:02.928Z → 2026-10-22T14:49:04.192Z
- tests/phase22/bol_analysis.ts: PASS; 2026-10-22T14:49:04.209Z → 2026-10-22T14:49:04.706Z
- tests/phase22/bol_analysis_bridge.ts: PASS; 2026-10-22T14:49:04.723Z → 2026-10-22T14:49:05.308Z
- tests/phase22/planner_scope.ts: PASS; 2026-10-22T14:49:05.326Z → 2026-10-22T14:49:05.818Z
- tests/phase22/runtime_recovery.ts: PASS; 2026-10-22T14:49:05.837Z → 2026-10-22T14:49:06.699Z
- tests/phase22/submit_goal_planner.ts: PASS; 2026-10-22T14:49:06.717Z → 2026-10-22T14:49:07.474Z
- tests/phase22/submit_goal_surface.ts: PASS; 2026-10-22T14:49:07.501Z → 2026-10-22T14:49:08.295Z

### core-reliability — FAIL

2026-10-22T14:49:09.139Z → 2026-10-22T14:49:30.233Z

```sh
docker run --rm --name sam-verify-1792680390993-81d5d06f-job-12 --label sam.verification.run=sam-verify-1792680390993-81d5d06f --init --network container:sam-verify-1792680390993-81d5d06f-pg --mount type=bind,src=/tmp/sam-verify-GL9r8P/source,dst=/app --workdir /app --user 1000:1000 --env HOME=/tmp --env SAM_CORE_TEST_DATABASE_URL=postgres://postgres:verification-fixture@127.0.0.1:5432/sam_core_test --env SAM_VERIFICATION_SOURCE_SHA=160dd9b694f739f40d31e25a209b7daf6fb962e6 node:22-bookworm@sha256:82693da96a4e38b8c0e2bf0c5df58fcb86d2d25e5a235c07748f09bfa38567c2 npm run test:core-reliability
```
Exit: 1; signal: none; 2026-10-22T14:49:09.141Z → 2026-10-22T14:49:30.233Z


### provider-auth — NOT_RUN

not started → not completed


### postgres-tls — NOT_RUN

not started → not completed


### contracts — NOT_RUN

not started → not completed


### synthetic-pilot — NOT_RUN

not started → not completed


### managed-schema — NOT_RUN

not started → not completed


### local-bundle — NOT_RUN

not started → not completed


### closed-setup — NOT_RUN

not started → not completed


### database-contract — NOT_RUN

not started → not completed


### prelaunch-gate — NOT_RUN

not started → not completed


### render-migration-compatibility — NOT_RUN

not started → not completed


### render-google-oauth-contracts — NOT_RUN

not started → not completed


### integration-migrations — NOT_RUN

not started → not completed


### integration-oauth-mcp — NOT_RUN

not started → not completed


### integration-orchestration — NOT_RUN

not started → not completed


### specialist-reasoning — NOT_RUN

not started → not completed


### specialist-gateway — NOT_RUN

not started → not completed


### specialist-provenance — NOT_RUN

not started → not completed


### specialist-learning-fairness — NOT_RUN

not started → not completed


### specialist-evaluation — NOT_RUN

not started → not completed


### evaluation-budget — NOT_RUN

not started → not completed


### evaluation-adapter — NOT_RUN

not started → not completed


### evaluation-orchestration — NOT_RUN

not started → not completed


### evaluation-independent-review — NOT_RUN

not started → not completed


### evaluation-commercial-market — NOT_RUN

not started → not completed


### evaluation-commercial-profitability — NOT_RUN

not started → not completed


### evaluation-commercial-suppliers — NOT_RUN

not started → not completed


### migration-upgrade-rollback — NOT_RUN

not started → not completed


### specialist-restart-prepare — NOT_RUN

not started → not completed


### evaluation-restart-prepare — NOT_RUN

not started → not completed


### postgres-restart — NOT_RUN

not started → not completed


### migration-after-restart — NOT_RUN

not started → not completed


### specialist-restart-check — NOT_RUN

not started → not completed


### evaluation-restart-check — NOT_RUN

not started → not completed


### phase0-migrations — NOT_RUN

not started → not completed


### phase0-acceptance — NOT_RUN

not started → not completed


### phase0-postgres — NOT_RUN

not started → not completed


### tenant-isolation — NOT_RUN

not started → not completed


### fail-closed-security — NOT_RUN

not started → not completed


### clean-image — NOT_RUN

not started → not completed


### image-contract — NOT_RUN

not started → not completed


### application-startup-restart — NOT_RUN

not started → not completed


### source-integrity — NOT_RUN

not started → not completed


### cleanup — PASS

2026-10-22T14:49:30.240Z → 2026-10-22T14:49:31.204Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-pg
```
Exit: 0; signal: none; 2026-10-22T14:49:30.245Z → 2026-10-22T14:49:30.276Z

```sh
docker rm --force --volumes sam-verify-1792680390993-81d5d06f-pg
```
Exit: 0; signal: none; 2026-10-22T14:49:30.276Z → 2026-10-22T14:49:30.799Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-1
```
Exit: 1; signal: none; 2026-10-22T14:49:30.799Z → 2026-10-22T14:49:30.830Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-2
```
Exit: 1; signal: none; 2026-10-22T14:49:30.830Z → 2026-10-22T14:49:30.859Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-3
```
Exit: 1; signal: none; 2026-10-22T14:49:30.859Z → 2026-10-22T14:49:30.888Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-4
```
Exit: 1; signal: none; 2026-10-22T14:49:30.888Z → 2026-10-22T14:49:30.910Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-5
```
Exit: 1; signal: none; 2026-10-22T14:49:30.910Z → 2026-10-22T14:49:30.937Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-6
```
Exit: 1; signal: none; 2026-10-22T14:49:30.937Z → 2026-10-22T14:49:30.963Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-7
```
Exit: 1; signal: none; 2026-10-22T14:49:30.963Z → 2026-10-22T14:49:30.990Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-8
```
Exit: 1; signal: none; 2026-10-22T14:49:30.990Z → 2026-10-22T14:49:31.009Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-9
```
Exit: 1; signal: none; 2026-10-22T14:49:31.009Z → 2026-10-22T14:49:31.032Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-10
```
Exit: 1; signal: none; 2026-10-22T14:49:31.032Z → 2026-10-22T14:49:31.056Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-11
```
Exit: 1; signal: none; 2026-10-22T14:49:31.056Z → 2026-10-22T14:49:31.077Z

```sh
docker inspect --format '{{index .Config.Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-job-12
```
Exit: 1; signal: none; 2026-10-22T14:49:31.077Z → 2026-10-22T14:49:31.098Z

```sh
docker network inspect --format '{{index .Labels "sam.verification.run"}}' sam-verify-1792680390993-81d5d06f-net
```
Exit: 0; signal: none; 2026-10-22T14:49:31.098Z → 2026-10-22T14:49:31.113Z

```sh
docker network rm sam-verify-1792680390993-81d5d06f-net
```
Exit: 0; signal: none; 2026-10-22T14:49:31.113Z → 2026-10-22T14:49:31.174Z


Exact structured commands, suite results and evidence hashes: [report.json](report.json).
No GitHub status was posted. A local pass cannot satisfy a required hosted check or authorize merge/deployment.
